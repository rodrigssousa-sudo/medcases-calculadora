# RELATORIO CLINICO - LOTE 088

- Medico revisor: Dra Eugenia Marques
- Data: 20-09-2026
- Resultado: APROVADO INTEGRALMENTE
- Excecoes: nenhuma
- Conteudo clinico alterado apos parecer: NAO
- Bloqueios granulares: preservados
- Integracao tecnica: NAO INICIADA
- Publicacao: BLOQUEADA

## fenoterol_gotas
Bloqueios: 1
- AUTOMACAO_DE_DOSE_E_GOTAS_BLOQUEADA: a bula operacional consultada remete a padrão Anvisa de 2019; confirmar vigência atual antes de liberar cálculo.
Pendencias: 2
- Registro/apresentação na Argentina não confirmado.
- Diretriz clínica independente atual não incorporada.

## hidrocortisona_iv
Bloqueios: 1
- CALCULO_GENERICO_IV_BLOQUEADO: dose e intervalo variam por doença e resposta; a faixa 100-500 mg não deve virar uma regra universal.
Pendencias: 2
- Apresentações/registros AR/BR não confirmados.
- Diretriz independente por indicação não incorporada.

## metilprednisolona_iv
Bloqueios: 2
- CALCULO_GENERICO_BLOQUEADO: o esquema 30 mg/kg não é universal e a dose depende da indicação.
- USO_NEONATAL_BLOQUEADO_SE_FORMULACAO_CONTIVER_BENZIL_ALCOOL.
Pendencias: 2
- Registro/apresentação AR/BR não confirmados.
- Diretriz independente por indicação não incorporada.

## prometazina_im
Bloqueios: 1
- PEDIATRIA_AUTOMATICA_BLOQUEADA: <2 anos é contraindicado e >=2 anos exige individualização; não há regra universal por kg nesta ficha.
Pendencias: 2
- Registro/apresentação AR/BR não confirmados.
- Diretriz independente por indicação não incorporada.

## salbutamol_nebulizacao
Bloqueios: 2
- PEDIATRIA_<12_ANOS_BLOQUEADA_NESTA_APRESENTACAO: a fonte de 0,5% documenta regime para >=12 anos; outras apresentações exigem ficha própria.
- CONVERSAO_ML_BLOQUEADA_SE_CONCENTRACAO_NAO_FOR_CONFIRMADA_COMO_2_5_MG_0_5_ML.
Pendencias: 2
- Apresentação/registros AR/BR não confirmados.
- Diretriz independente atual não incorporada.

## acido_tranexamico_iv
Bloqueios: 1
- INDICACOES_FORA_DA_BULA_EUA_BLOQUEADAS: trauma, hemorragia obstétrica e outros regimes não foram validados nesta ficha.
Pendencias: 2
- Apresentação/registros AR/BR não confirmados.
- Diretrizes específicas para outras indicações não incorporadas.

## albumina_humana_20
Bloqueios: 1
- INFUSAO_AUTOMATICA_BLOQUEADA: a velocidade é individualizada e varia por indicação/estado volêmico.
Pendencias: 2
- Registro/apresentação AR/BR não confirmados.
- Diretriz independente por indicação não incorporada.

## complexo_protrombinico
Bloqueios: 2
- INTERCAMBIABILIDADE_DE_PRODUTO_BLOQUEADA: esta ficha documenta especificamente KCENTRA/PCC4.
- PEDIATRIA_BLOQUEADA: segurança/eficácia não estabelecidas.
Pendencias: 2
- Registro/apresentação AR/BR não confirmados.
- Diretriz independente local de reversão de anticoagulação não incorporada.

## crioprecipitado
Bloqueios: 1
- CALCULO_AUTOMATICO_BLOQUEADO: conteúdo por bolsa/pool varia e a dose deve usar rótulo local + alvo de fibrinogênio/viscoelasticidade.
Pendencias: 2
- Disponibilidade e normas específicas AR/BR do serviço de hemoterapia não confirmadas.
- Diretriz local de transfusão maciça/hipofibrinogenemia não incorporada.

## desmopressina_iv
Bloqueios: 1
- PEDIATRIA_AUTOMATICA_BLOQUEADA: dose e monitorização dependem da indicação, resposta e risco de hiponatremia.
Pendencias: 2
- Registro/apresentação AR/BR não confirmados.
- Diretriz independente específica por indicação não incorporada.
