# MEDCASES GOLD33 - LOTE 088 - REFERENCIAS

Parecer: Dra Eugenia Marques | 20-09-2026 | APROVADO INTEGRALMENTE | Arquivo revisado: 088

## fenoterol_gotas
- ANVISA/Bulário - bromidrato de fenoterol solução gotas 5 mg/mL, Prati-Donaduzzi, bula do paciente; apresentação, uso oral/inalatório, posologia, diluição, contraindicações e reações adversas; bula padrão aprovada pela Anvisa em 28/01/2019; consultada 20-09-2026. https://bula-anvisa.s3.sa-east-1.amazonaws.com/125680124_paciente.pdf

## hidrocortisona_iv
- DailyMed/FDA - Hydrocortisone sodium succinate for injection, USP, Zydus Pharmaceuticals USA; label updated 08-05-2026; IV/IM, dose, administração, contraindicações, interações e segurança; consultado 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=37534164-9de5-4bb3-9f87-341dfcf90883

## metilprednisolona_iv
- DailyMed/FDA - SOLU-MEDROL (methylprednisolone sodium succinate for injection, USP), Pharmacia & Upjohn; label effective 25-06-2026; IV/IM, reconstituição, doses e advertências; consultado 20-09-2026. https://www.dailymed.nlm.nih.gov/dailymed/fda/fdaDrugXsl.cfm?setid=7271310c-7764-4812-aa30-a5e90987c7a9&type=display

## prometazina_im
- DailyMed/FDA - Promethazine hydrochloride injection, Hikma; revised December 2023, current SPL packaging 2025; deep IM preferred, dosing, contraindications and tissue injury warnings; consultado 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=13d9e59d-eadb-41d5-9f47-9c11a6efb31c

## salbutamol_nebulizacao
- DailyMed/FDA - Albuterol Sulfate Inhalation Solution 0.5%, Ritedose Pharmaceuticals; updated 30-04-2026, 2.5 mg/0.5 mL concentrate; nebulization dosing/dilution; consultado 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=fdb4ac5a-bf0d-4896-89f7-1828c081b79e

## acido_tranexamico_iv
- DailyMed/FDA - CYKLOKAPRON (tranexamic acid) injection, Pfizer; updated 03-09-2025 with boxed warning and dosage changes 08/2025; consultado 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=6e89a7d9-4da4-42aa-b7f8-c602c24eefe5

## albumina_humana_20
- DailyMed/FDA - ALBUTEIN (Albumin Human) 20%, Grifols; IV use, indication-specific dosing, dilution and hypervolemia warnings; consultado 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=e4304edc-8c80-4118-9d86-7a34c76aa56f

## complexo_protrombinico
- DailyMed/FDA - KCENTRA, Prothrombin Complex Concentrate (Human), CSL Behring; updated 16-05-2023; 4-factor PCC for urgent VKA reversal in adults; consultado 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=eee1afb8-324c-42e4-8bf0-f0c9da5e6d42

## crioprecipitado
- FDA - An Acceptable Circular of Information for the Use of Human Blood and Blood Components, Guidance for Industry, September 2024, recognizing the June 2024 Circular; consultado 20-09-2026. https://www.fda.gov/regulatory-information/search-fda-guidance-documents/acceptable-circular-information-use-human-blood-and-blood-components
- AABB/American Red Cross/America’s Blood Centers/Armed Services Blood Program - Circular of Information for the Use of Human Blood and Blood Components, June 2024; Cryoprecipitated AHF description, indications, dosing and administration; consultado 20-09-2026. https://www.aabb.org/docs/default-source/default-document-library/resources/circular-of-information-watermark.pdf

## desmopressina_iv
- DailyMed/FDA - Desmopressin Acetate Injection, 4 mcg/mL, Caplin Steriles USA; March 2026 label; IV/SC, central DI, hemophilia A and type 1 vWD, boxed hyponatremia warning; consultado 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=84dbb392-4535-4cbc-af60-75abb494f26e
