# MEDCASES GOLD33 - LOTE 092 - REFERENCIAS

Parecer: Dra Eugenia Marques | 20-09-2026 | APROVADO INTEGRALMENTE | Arquivo revisado: 092

## fosfomicina_trometamol
- 1. DailyMed — Fosfomycin tromethamine granules for oral solution, updated 2026-04-09. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=4f206750-8126-99a3-e063-6294a90ade4c&version=1

## levofloxacino_iv
- 1. DailyMed — Levofloxacin injection, solution 5 mg/mL, effective 2026-07-21. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=699fbdb8-a6fd-476a-9b80-08197d869534

## metronidazol_iv
- 1. DailyMed — Metronidazole Injection USP 500 mg/100 mL, updated 2026-06-09. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=7187779a-1f4c-4607-af53-4119e324aad5

## nitrofurantoina_macrocristais
- 1. DailyMed — Nitrofurantoin macrocrystals capsules, updated 2026-04-14. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=341c75ac-fba5-480d-a221-868c4195cb6f

## dipirona_gotas
- 1. Bayer Bulário — ASPDIP dipirona monoidratada gotas 500 mg/mL, bula profissional/paciente. https://www.bulario.bayer.com.br/cuidados-com-a-saude/aspdip-gotas
- 2. ANVISA Farmacopeia Brasileira — Dipirona monoidratada IF162-00. https://bibliotecadigital.anvisa.gov.br/jspui/handle/anvisa/1166

## dipirona_supositorio
- 1. Novalgina — dipirona monoidratada supositório 300 mg, bula/produto. https://www.novalgina.com.br/bulas/novalgina-bula-supositorio.pdf

## paracetamol_gotas
- 1. Prati-Donaduzzi — Paracetamol solução gotas 200 mg/mL, bula profissional reproduzida. https://www.bula.gratis/prati_donaduzzi_cia_ltda/1/paracetamol/profissional
- 2. ANVISA — alerta sobre uso incorreto de paracetamol e diferenças entre formulações líquidas. https://www.gov.br/anvisa/pt-br/assuntos/noticias-anvisa/2021/anvisa-alerta-sobre-o-uso-incorreto-de-paracetamol

## paracetamol_suspensao
- 1. Medley — Paracetamol suspensão oral 100 mg/mL, bula do produto. https://bula.com.br/original/paracetamol-suspensao-oral-100-mgml
- 2. DailyMed — Children’s Tylenol acetaminophen suspension 160 mg/5 mL, updated 2026-06-12. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3162733b-9382-39f1-e063-6294a90ac420
- 3. ANVISA — alerta sobre formulações líquidas de paracetamol. https://www.gov.br/anvisa/pt-br/assuntos/noticias-anvisa/2021/anvisa-alerta-sobre-o-uso-incorreto-de-paracetamol

## ibuprofeno_gotas
- 1. Ibupril — ibuprofeno suspensão gotas 100 mg/mL, bula do produto. https://bula.com.br/original/ibupril-gotas-100-mgml
- 2. DailyMed — Children’s Ibuprofen suspension 100 mg/5 mL, updated 2026-05-06. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=e304f791-755d-4d11-a9f6-3d46ec84197f&version=2

## ibuprofeno_suspensao
- 1. ISP Chile — registro vigente Ibuprofeno suspensión oral 100 mg/5 mL, renovado 2025. https://registrosanitario.ispch.gob.cl/Ficha.aspx?RegistroISP=F-22143%2F25
- 2. Laboratorio Chile/Teva — Ibuprofeno 100 mg/5 mL suspensión oral. https://www.laboratoriochile.cl/producto/ibuprofeno-100-mg-5-ml/
- 3. DailyMed — Children’s Ibuprofen suspension 100 mg/5 mL, updated 2026-05-06. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=e304f791-755d-4d11-a9f6-3d46ec84197f&version=2
