# RELATORIO CLINICO - LOTE 092

- Medico revisor: Dra Eugenia Marques
- Data: 20-09-2026
- Resultado: APROVADO INTEGRALMENTE
- Excecoes: nenhuma
- Conteudo clinico alterado apos parecer: NAO
- Bloqueios granulares: preservados
- Integracao tecnica: NAO INICIADA
- Publicacao: BLOQUEADA

## fosfomicina_trometamol
Bloqueios: 3
- PEDIATRIA_NAO_AUTOMATIZAVEL
- AJUSTE_RENAL_NUMERICO_NAO_DOCUMENTADO
- NAO_USAR_PARA_PIELONEFRITE_OU_REGIME_REPETIDO_SEM_FONTE
Pendencias: 1
- Disponibilidade/marca local AR/BR não confirmada.

## levofloxacino_iv
Bloqueios: 4
- SELECAO_DE_INDICACAO_OBRIGATORIA
- PEDIATRIA_RESTRITA_A_ANTHRAX_PESTE
- AJUSTE_RENAL_DEPENDE_DO_REGIME_BASE
- INFUSAO_RAPIDA_BOLUS_PROIBIDOS
Pendencias: 1
- Apresentação/local AR/BR não confirmada neste dossiê.

## metronidazol_iv
Bloqueios: 3
- NEONATAL_EXIGE_IDADE_POS_MENSTRUAL
- AJUSTE_HEPATICO_NUMERICO_NAO_DOCUMENTADO
- INTERACOES_ALCOOL_DISSULFIRAM_DEVEM_SER_EXPLICITAS
Pendencias: 1
- Disponibilidade/local AR/BR específica não confirmada.

## nitrofurantoina_macrocristais
Bloqueios: 3
- LIMIAR_RENAL_CONFLITANTE_EXIGE_REVISAO_MEDICA
- NEONATO_MENOR_1_MES_CONTRAINDICADO
- NAO_MISTURAR_MACROCRISTAIS_COM_MONOIDRATO_MACROCRISTAIS
Pendencias: 1
- Disponibilidade local AR/BR não confirmada.

## dipirona_gotas
Bloqueios: 3
- CONVERSAO_GOTAS_EXIGE_PRODUTO_EXATO
- AGRANULOCITOSE_ALERTA_CRITICO
- PEDIATRIA_MENOR_3_MESES_OU_5KG_BLOQUEADA
Pendencias: 1
- Marca/apresentação AR não confirmada.

## dipirona_supositorio
Bloqueios: 3
- IDADE_MENOR_4_ANOS_BLOQUEADA
- NAO_FRACIONAR_SUPOSITORIO
- AGRANULOCITOSE_ALERTA_CRITICO
Pendencias: 1
- Posologia adulta não documentada para esta apresentação.

## paracetamol_gotas
Bloqueios: 2
- CONVERSAO_GOTAS_VARIAVEL_NAO_AUTOMATIZAR_SEM_DISPOSITIVO
- LIMITE_DIARIO_DEVE_SOMAR_TODAS_AS_FONTES_DE_PARACETAMOL
Pendencias: 1
- Formulações líquidas com concentrações diferentes existem; não intercambiar.

## paracetamol_suspensao
Bloqueios: 2
- CONCENTRACAO_OBRIGATORIA_PARA_CALCULO_ML
- LIMITE_DIARIO_CUMULATIVO_OBRIGATORIO
Pendencias: 1
- Existem apresentações 32 e 100 mg/mL; o ID genérico não codifica a concentração.

## ibuprofeno_gotas
Bloqueios: 3
- CONVERSAO_GOTAS_EXIGE_PRODUTO_EXATO
- IDADE_MENOR_6_MESES_BLOQUEADA
- RISCO_AINE_RENAL_GI_GESTACIONAL
Pendencias: 1
- Apresentações de outros fabricantes podem ter equivalência de gotas distinta.

## ibuprofeno_suspensao
Bloqueios: 3
- CONCENTRACAO_20MG_ML_OBRIGATORIA
- NAO_MISTURAR_COM_GOTAS_100MG_ML
- DOSE_ADULTA_NUMERICA_NAO_DOCUMENTADA_NESTE_PRODUTO
Pendencias: 1
- PT é tradução técnica de fonte Chile/ISP para esta apresentação; não equivale a autorização Anvisa.
