# Lote 093 - Referências

As referências clínicas pertencem ao candidato revisado. O artefato candidato exato não está disponível no runtime atual; nenhuma referência foi inventada ou reconstruída.
