# Referencias - Lote 104 homologado

## acido_tranexamico_iv
- DailyMed/NLM EUA - Tranexamic Acid Injection, atualizado 14-08-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=a93d6ef3-e160-db0d-142f-9b91af8d8428
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=a93d6ef3-e160-db0d-142f-9b91af8d8428
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=a93d6ef3-e160-db0d-142f-9b91af8d8428

## albumina_humana_20
- DailyMed/NLM EUA - ALBUMIN (HUMAN) 20%, Octapharma. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=18a9c174-f892-e45f-ca4b-bd5a180c1539
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=18a9c174-f892-e45f-ca4b-bd5a180c1539
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=18a9c174-f892-e45f-ca4b-bd5a180c1539

## complexo_protrombinico
- DailyMed/NLM EUA - KCENTRA. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=eee1afb8-324c-42e4-8bf0-f0c9da5e6d42
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=eee1afb8-324c-42e4-8bf0-f0c9da5e6d42
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=eee1afb8-324c-42e4-8bf0-f0c9da5e6d42

## crioprecipitado
- AABB - Circular of Information for the Use of Human Blood and Blood Components, June 2024. https://www.aabb.org/docs/default-source/default-document-library/resources/circular-of-information-watermark.pdf
- FDA - recognizes June 2024 AABB Circular as acceptable. https://www.fda.gov/regulatory-information/search-fda-guidance-documents/acceptable-circular-information-use-human-blood-and-blood-components
- ref.pt: https://www.aabb.org/docs/default-source/default-document-library/resources/circular-of-information-watermark.pdf
- ref.es: https://www.aabb.org/docs/default-source/default-document-library/resources/circular-of-information-watermark.pdf

## desmopressina_iv
- DailyMed/NLM EUA - Desmopressin Acetate Injection, current 2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=84dbb392-4535-4cbc-af60-75abb494f26e
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=84dbb392-4535-4cbc-af60-75abb494f26e
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=84dbb392-4535-4cbc-af60-75abb494f26e

## fibrinogenio_humano
- DailyMed/NLM EUA - FIBRYGA, current 2025/2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=e3422d2a-2cb6-6f49-0be7-cb960b3d5bd5
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=e3422d2a-2cb6-6f49-0be7-cb960b3d5bd5
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=e3422d2a-2cb6-6f49-0be7-cb960b3d5bd5

## fitomenadiona_vitamina_k_iv
- DailyMed/NLM EUA - Phytonadione Injection, atualizado 04-02-2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=3d571642-3d3a-41ae-855e-304ae4fff459
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=3d571642-3d3a-41ae-855e-304ae4fff459
- ref.es: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=3d571642-3d3a-41ae-855e-304ae4fff459

## plasma_fresco_congelado
- AABB - Circular of Information for Human Blood and Blood Components, June 2024. https://www.aabb.org/docs/default-source/default-document-library/resources/circular-of-information-watermark.pdf
- FDA - recognizes June 2024 AABB Circular. https://www.fda.gov/regulatory-information/search-fda-guidance-documents/acceptable-circular-information-use-human-blood-and-blood-components
- ref.pt: https://www.aabb.org/docs/default-source/default-document-library/resources/circular-of-information-watermark.pdf
- ref.es: https://www.aabb.org/docs/default-source/default-document-library/resources/circular-of-information-watermark.pdf

## biperideno_im
- AEMPS/CIMA - Akineton 5 mg/mL solucion inyectable, ficha tecnica atual. https://cima.aemps.es/cima/dochtml/ft/28994/FT_28994.html
- ref.pt: https://cima.aemps.es/cima/dochtml/ft/28994/FT_28994.html
- ref.es: https://cima.aemps.es/cima/dochtml/ft/28994/FT_28994.html

## clorpromazina_im
- DailyMed/NLM EUA - Chlorpromazine Hydrochloride Injection 25 mg/mL, active 2025/2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=5831e15a-3efa-48bb-9d49-8451f78d9868
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=5831e15a-3efa-48bb-9d49-8451f78d9868
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=5831e15a-3efa-48bb-9d49-8451f78d9868

