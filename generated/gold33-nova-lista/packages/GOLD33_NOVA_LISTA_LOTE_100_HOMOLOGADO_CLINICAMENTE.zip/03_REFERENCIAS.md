# Referencias - Lote 100 homologado

## antimoniato_de_meglumina
- WHO EMRO - Summary of clinical scenarios and treatment of cutaneous leishmaniasis. https://www.emro.who.int/ar/neglected-tropical-diseases/information-resources-leishmaniasis/clinical-signs-and-treatment.html
- WHO EMRO - Manual for case management of cutaneous leishmaniasis; product example 81 mg Sb5+/mL. https://www.emro.who.int/images/stories/zoonoses/manual_leishmaniasis_edited_mb_draft_for_web_1_5_13.pdf
- WHO - 29 Jul 2026 update for visceral and post-kala-azar dermal leishmaniasis. https://www.who.int/news/item/29-07-2026-who-updates-treatment-guidelines-on-visceral-and-post-kala-azar-dermal-leishmaniasis
- ref.pt: https://www.emro.who.int/ar/neglected-tropical-diseases/information-resources-leishmaniasis/clinical-signs-and-treatment.html
- ref.es: https://www.emro.who.int/ar/neglected-tropical-diseases/information-resources-leishmaniasis/clinical-signs-and-treatment.html

## artemeter_lumefantrina
- DailyMed/NLM EUA - COARTEM, atualizado 26-03-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=7866ec19-dfac-47d4-a53f-511a12643cbf
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=7866ec19-dfac-47d4-a53f-511a12643cbf
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=7866ec19-dfac-47d4-a53f-511a12643cbf

## baloxavir_marboxil
- Genentech - XOFLUZA Full Prescribing Information, consultado em 20-09-2026. https://www.gene.com/download/pdf/xofluza_prescribing.pdf
- ref.pt: https://www.gene.com/download/pdf/xofluza_prescribing.pdf
- ref.es: https://www.gene.com/download/pdf/xofluza_prescribing.pdf

## benznidazol
- DailyMed/NLM EUA - Benznidazole Tablets, rotulo atual consultado 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8983d6a0-f63f-4f8e-bba4-38223f39e29b
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8983d6a0-f63f-4f8e-bba4-38223f39e29b
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8983d6a0-f63f-4f8e-bba4-38223f39e29b

## bezlotoxumabe
- Merck - ZINPLAVA Prescribing Information, revised 05/2023, consultado 20-09-2026. https://www.merck.com/product/usa/pi_circulars/z/zinplava/zinplava_pi.pdf
- ref.pt: https://www.merck.com/product/usa/pi_circulars/z/zinplava/zinplava_pi.pdf
- ref.es: https://www.merck.com/product/usa/pi_circulars/z/zinplava/zinplava_pi.pdf

## capreomicina
- DailyMed/NLM - CAPASTAT Sulfate historical label, Rev 09/2019. https://dailymed.nlm.nih.gov/dailymed/downloadpdffile.cfm?setId=808e4421-2b9c-41e1-a82c-39256b112ae8
- WHO TB Knowledge Sharing / consolidated guidance - capreomycin no longer recommended in MDR-TB regimens. https://tbksp.who.int/en/node/2978
- WHO consolidated operational handbook on TB, Module 4 (2025). https://www.who.int/publications/i/item/9789240108141
- ref.pt: https://tbksp.who.int/en/node/2978
- ref.es: https://tbksp.who.int/en/node/2978

## cicloserina
- DailyMed/NLM EUA - Cycloserine 250 mg capsules, current version Jul 2024. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8e7e2665-7a3d-3f54-9f92-5fe845f02ef9
- WHO-PQ - Cycloserine 250 mg capsules WHOPAR Part 4, pediatric/renal dosing. https://extranet.who.int/prequal/sites/default/files/whopar_files/TB385%20part4v1.pdf
- WHO consolidated operational handbook on TB, Module 4, 2025. https://www.who.int/publications/i/item/9789240108141
- ref.pt: https://extranet.who.int/prequal/sites/default/files/whopar_files/TB385%20part4v1.pdf
- ref.es: https://extranet.who.int/prequal/sites/default/files/whopar_files/TB385%20part4v1.pdf

## cidofovir
- DailyMed/NLM EUA - VISTIDE (cidofovir) injection. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=90639fc6-0295-4115-98f0-054b783850ce
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=90639fc6-0295-4115-98f0-054b783850ce
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=90639fc6-0295-4115-98f0-054b783850ce

## clofazimina
- WHO TB Knowledge Sharing - current DR-TB regimen information, clofazimine 100 mg daily. https://tbksp.who.int/pt-br/node/3033
- WHO consolidated TB medicines information sheet - clofazimine. https://iris.who.int/bitstream/handle/10665/365309/9789240065352-eng.pdf
- WHO Prequalification TB362 - Clofazimine 100 mg film-coated tablet. https://extranet.who.int/prequal/WHOPAR/tb362
- ref.pt: https://tbksp.who.int/pt-br/node/3033
- ref.es: https://tbksp.who.int/pt-br/node/3033

## cloroquina
- DailyMed/NLM EUA - Chloroquine Phosphate Tablets 500 mg (=300 mg base), current version Apr 2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f4ac1556-0522-76e3-e053-2a95a90a5ba8
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f4ac1556-0522-76e3-e053-2a95a90a5ba8
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f4ac1556-0522-76e3-e053-2a95a90a5ba8

