# Lote 094 — Referências homologadas

Parecer médico: Dra Eugenia Marques, 20-09-2026, aprovado integralmente, sem exceções informadas.

## fluticasona_spray_nasal
- DailyMed/FDA EUA - Fluticasone Propionate Nasal Spray, USP, atualizado 19-08-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=bc08915f-fa3a-4509-a01c-42b577f39b99
- ref PT/ES: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=bc08915f-fa3a-4509-a01c-42b577f39b99

## ondansetrona_solucao_oral
- DailyMed EUA - Ondansetron oral solution 4 mg/5 mL, rótulo atualizado 02-01-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?audience=consumer&setid=2086bae8-7c3c-4663-93ac-c86407c524c2
- ref PT/ES: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?audience=consumer&setid=2086bae8-7c3c-4663-93ac-c86407c524c2

## bromoprida_gotas
- Aché/BR - Bromoprida solução gotas 4 mg/mL, bula de produto. https://www.ache.com.br/produto/genericos-sob-prescricao/bromoprida/
- Aché/BR - comunicado de descontinuação temporária, janeiro/2026. https://www.ache.com.br/descontinuacao-temporaria/bromoprida/
- ref PT/ES: https://www.ache.com.br/produto/genericos-sob-prescricao/bromoprida/

## simeticona_emulsao
- Aché/BR - Flagass (simeticona) emulsão gotas 75 mg/mL, bula aprovada 04-06-2025. https://www.ache.com.br/produto/isentos-de-prescricao/flagass/
- ref PT/ES: https://www.ache.com.br/produto/isentos-de-prescricao/flagass/

## racecadotrila_granulado
- AEMPS/CIMA - Tiorfan Lactantes 10 mg, ficha técnica. https://cima.aemps.es/cima/dochtml/ft/64816/FichaTecnica_64816.html
- AEMPS/CIMA - Tiorfan Niños 30 mg, ficha técnica revisada 14-11-2024. https://cima.aemps.es/cima/dochtml/ft/64809/FT_64809.html
- ref PT/ES: https://cima.aemps.es/cima/dochtml/ft/64809/FT_64809.html

## sais_para_reidratacao_oral
- WHO/UNICEF - Oral rehydration salts: production of the new ORS, baixa osmolaridade 245 mOsm/L. https://www.who.int/publications/i/item/WHO-FCH-CAH-06.1
- WHO - Guideline on management of pneumonia and diarrhoea in children up to 10 years, publicação 2024/2025. https://www.who.int/publications/i/item/9789240103412
- ref PT/ES: https://www.who.int/publications/i/item/9789240103412

## zinco_solucao_oral
- WHO - Guideline on management of pneumonia and diarrhoea in children up to 10 years, publicação 2024/2025. https://www.who.int/publications/i/item/9789240103412
- WHO Prequalification - guidance for zinc oral liquid; exemplos de concentração para 5 mg de zinco elementar. https://extranet.who.int/prequal/key-resources/documents/guidance-submission-applications-prequalification-zinc-tablets-and-zinc
- ref PT/ES: https://www.who.int/publications/i/item/9789240103412

## dexclorfeniramina_xarope
- Hypera/BR - Polaramine Solução, uso e posologia atuais. https://www.hypera.com.br/produtos/isentos-de-prescricao/polaramine-solucao
- Cimed/BR - bula profissional de maleato de dexclorfeniramina solução oral 2 mg/5 mL, atualização de bula indicada em 2022 (consulta via Bulário espelhado).
- ref PT/ES: https://www.hypera.com.br/produtos/isentos-de-prescricao/polaramine-solucao

## dexclorfeniramina_gotas
- Hypera/BR - Polaramine Gotas, posologia atual e apresentação comercial. https://www.hypera.com.br/produtos/isentos-de-prescricao/polaramine-gotas
- Polaramine Gotas - bula do produto: 2,8 mg/mL, 28 gotas/mL, 0,1 mg/gota (cópia pública de bula do produto consultada).
- ref PT/ES: https://www.hypera.com.br/produtos/isentos-de-prescricao/polaramine-gotas

## loratadina_xarope
- Aché/BR - Loratadina xarope 1 mg/mL, bula aprovada pela Anvisa em 01-10-2019 e disponível atualmente no fabricante. https://www.ache.com.br/produto/genericos-isentos-de-prescricao/loratadina-xarope/
- ref PT/ES: https://www.ache.com.br/produto/genericos-isentos-de-prescricao/loratadina-xarope/

