# Referencias - Lote 099 homologado

## oxazepam
- DailyMed/NLM EUA - Oxazepam capsules, atualizado 11-07-2025. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=67f821fa-5663-4d69-82c9-5ee13a09f324
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=67f821fa-5663-4d69-82c9-5ee13a09f324
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=67f821fa-5663-4d69-82c9-5ee13a09f324

## buspirona
- DailyMed/NLM EUA - Buspirone Hydrochloride tablets, rotulo atual consultado em 2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=801803eb-be17-4064-8813-7ccf52316cde
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=801803eb-be17-4064-8813-7ccf52316cde
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=801803eb-be17-4064-8813-7ccf52316cde

## galantamina
- DailyMed/NLM EUA - Galantamine extended-release capsules. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=d0b75970-8d3d-408b-9e17-9cbad0f776b1
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=d0b75970-8d3d-408b-9e17-9cbad0f776b1
- ref.es: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=d0b75970-8d3d-408b-9e17-9cbad0f776b1

## entacapona
- DailyMed/NLM EUA - Entacapone tablets 200 mg, atualizado 2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=56327e32-3b06-4144-91a0-bb1908842e33
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=56327e32-3b06-4144-91a0-bb1908842e33
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=56327e32-3b06-4144-91a0-bb1908842e33

## clotiapina
- AEMPS/CIMA Espanha - Etumina 40 mg comprimidos, ficha tecnica. https://cima.aemps.es/cima/dochtml/ft/46584/FT_46584.html
- ref.pt: https://cima.aemps.es/cima/dochtml/ft/46584/FT_46584.html
- ref.es: https://cima.aemps.es/cima/dochtml/ft/46584/FT_46584.html

## glicose_50
- DailyMed/NLM EUA - Dextrose Injection 50%, atualizado 13-07-2026. https://dailymed-us-east-1.awsprod.nlm.nih.gov/dailymed/drugInfo.cfm?setid=4ed365da-4e62-4329-c1b9-c197ab4fb6e1
- ref.pt: https://dailymed-us-east-1.awsprod.nlm.nih.gov/dailymed/drugInfo.cfm?setid=4ed365da-4e62-4329-c1b9-c197ab4fb6e1
- ref.es: https://dailymed-us-east-1.awsprod.nlm.nih.gov/dailymed/drugInfo.cfm?setid=4ed365da-4e62-4329-c1b9-c197ab4fb6e1

## glucagon
- DailyMed/NLM EUA - Glucagon for Injection, atualizado 06-02-2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=34c3c58a-3d17-4a12-b592-971bdd41aeca
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=34c3c58a-3d17-4a12-b592-971bdd41aeca
- ref.es: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=34c3c58a-3d17-4a12-b592-971bdd41aeca

## hidroxicloroquina
- DailyMed/NLM EUA - Hydroxychloroquine sulfate tablets, atual em 2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=84b00366-96ef-41e1-bac6-5d24acdb9e1d
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=84b00366-96ef-41e1-bac6-5d24acdb9e1d
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=84b00366-96ef-41e1-bac6-5d24acdb9e1d

## metotrexato
- DailyMed/NLM EUA - Methotrexate tablets, atualizado 23-07-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=22e10810-16fb-4c84-bccf-972405b77ef8
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=22e10810-16fb-4c84-bccf-972405b77ef8
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=22e10810-16fb-4c84-bccf-972405b77ef8

## leflunomida
- DailyMed/NLM EUA - Leflunomide tablets, rotulo profissional atual 2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?audience=professional&setid=5d48fded-b43b-461a-8488-ca1da5c41a03
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?audience=professional&setid=5d48fded-b43b-461a-8488-ca1da5c41a03
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?audience=professional&setid=5d48fded-b43b-461a-8488-ca1da5c41a03

