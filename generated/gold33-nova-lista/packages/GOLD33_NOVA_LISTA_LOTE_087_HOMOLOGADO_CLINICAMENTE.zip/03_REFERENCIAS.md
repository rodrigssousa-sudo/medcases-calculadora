# Referencias - GOLD33 NOVA LISTA LOTE 087

Parecer: Dra Eugenia Marques, 20-09-2026, APROVADO INTEGRALMENTE, arquivo revisado 003, sem excecoes.

## soro_glicosado_10
- DailyMed/FDA US - Baxter Healthcare, Dextrose Injection (5% and 10%), atualização 11-06-2026; seções Indications, Dosage and Administration, Warnings, Adverse Reactions, Use in Specific Populations, Clinical Pharmacology. Acesso 2026-09-20. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3bb406a9-f5cb-403a-b1bb-5c4facbea3d5

## soro_glicosado_5
- DailyMed/FDA US - Baxter Healthcare, Dextrose Injection (5% and 10%), atualização 11-06-2026; seções Indications, Dosage and Administration, Warnings, Adverse Reactions, Use in Specific Populations, Clinical Pharmacology. Acesso 2026-09-20. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3bb406a9-f5cb-403a-b1bb-5c4facbea3d5

## soro_glicosado_50
- DailyMed/FDA US - Dextrose Injection 50%, etiqueta efetiva 31-08-2026; seções Indications, Dosage, Contraindications, Warnings, Adverse Reactions, Use in Specific Populations. Acesso 2026-09-20. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b8b77421-d687-45aa-82f6-d49bce644c10

## sulfato_de_magnesio_10
- Halex Istar/ANVISA BR - Isofarma Solução de Sulfato de Magnésio 10% e 50%, bula profissional BU020/06; Reg. MS 1.0311.0163; apresentações 100 mg/mL e 500 mg/mL; acesso 2026-09-20. https://halexistar.com.br/wp-content/uploads/2025/10/2-17102511.pdf

## sulfato_de_magnesio_50
- Halex Istar/ANVISA BR - Isofarma Solução de Sulfato de Magnésio 10% e 50%, bula profissional BU020/06; Reg. MS 1.0311.0163; apresentações 100 mg/mL e 500 mg/mL; acesso 2026-09-20. https://halexistar.com.br/wp-content/uploads/2025/10/2-17102511.pdf

## adrenalina_autoinjetavel
- DailyMed/FDA US - Epinephrine Injection auto-injector, versão publicada 23-03-2026; doses fixas 0,15/0,3 mg, anafilaxia >=15 kg. Acesso 2026-09-20. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=e13f05f1-7d21-49bb-b8d5-24bf9301c3d7

## aminofilina_iv
- DailyMed/FDA US - Aminophylline Injection USP, Hospira, 25 mg/mL, atualização 22-05-2026; Clinical Pharmacology, Indications, Warnings, Dosage, Adverse Reactions, Special Populations. Acesso 2026-09-20. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=9a663ef3-881f-48bd-2689-3713b24545c2

## betametasona_injetavel
- DailyMed/FDA US - CELESTONE SOLUSPAN (betamethasone sodium phosphate + betamethasone acetate) injectable suspension 6 mg/mL, atualização 06-03-2026; acesso 2026-09-20. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=bf78d1be-42d7-4837-92a5-49113a79278f&version=10

## brometo_de_ipratropio_nebulizacao
- DailyMed/FDA US - Ipratropium Bromide Inhalation Solution 0,02%, atualização 24-07-2026; dose 500 mcg/2,5 mL, COPD. Acesso 2026-09-20. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=6b730dd7-4d93-403a-bfd2-fa0efa298b75

## dexametasona_iv
- DailyMed/FDA US - Dexamethasone Sodium Phosphate Injection USP 10 mg/mL, IV/IM; etiqueta consultada em 2026-09-20. https://dailymed.nlm.nih.gov/dailymed/fda/fdaDrugXsl.cfm?setid=36854dbc-22f2-5df9-e063-6394a90ad934
