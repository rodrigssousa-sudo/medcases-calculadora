# RELATORIO CLINICO - LOTE 090

- Medico revisor: Dra Eugenia Marques
- Data: 20-09-2026
- Resultado: APROVADO INTEGRALMENTE
- Excecoes: nenhuma
- Conteudo clinico alterado apos parecer: NAO
- Bloqueios granulares: preservados
- Integracao tecnica: NAO INICIADA
- Publicacao: BLOQUEADA

## betametasona_obstetricia
Bloqueios: 2
- CONVERSAO_ML_BLOQUEADA_ATE_CONFIRMAR_FORMULACAO_E_CONCENTRACAO
- USO_FORA_CRITERIOS_WHO_24_34_SEMANAS_BLOQUEADO
Pendencias: 1
- Disponibilidade e apresentação específicas AR/BR não confirmadas.

## ergometrina
Bloqueios: 2
- HIPERTENSAO_GRAVE_PREECLAMPSIA_ECLAMPSIA_BLOQUEIAM_USO
- IV_RAPIDA_BLOQUEADA
Pendencias: 1
- Registro/apresentação AR/BR não confirmados.

## labetalol_iv
Bloqueios: 2
- ASMA_BRONCOESPASMO_BLOQUEIAM_USO
- BRADICARDIA_BLOQUEIO_AV_CHOQUE_IC_DESCOMPENSADA_BLOQUEIAM_USO
Pendencias: 1
- Apresentação específica AR/BR não confirmada.

## misoprostol_obstetrico
Bloqueios: 2
- CALCULO_AUTOMATICO_BLOQUEADO_SEM_INDICACAO_VIA_E_CICATRIZ_UTERINA
- INDUCAO_COM_CESARIANA_PREVIA_BLOQUEADA
Pendencias: 1
- Apresentações obstétricas específicas AR/BR não confirmadas.

## nifedipina_retard
Bloqueios: 2
- FORMULACAO_ER_NAO_PODE_SER_USADA_COMO_IR_DE_URGENCIA
- USO_SUBLINGUAL_BLOQUEADO
Pendencias: 1
- Marca/apresentação AR/BR não confirmada.

## ocitocina_iv
Bloqueios: 3
- MOTOR_DEVE_SEPARAR_IU_DE_mU_MIN
- BOLUS_IV_RAPIDO_BLOQUEADO
- INDUCAO_SEM_MONITORIZACAO_CONTINUA_BLOQUEADA
Pendencias: 1
- Apresentação AR/BR não confirmada.

## sulfato_de_magnesio_obstetricia
Bloqueios: 3
- AJUSTE_RENAL_AUTOMATICO_BLOQUEADO
- CONVERSAO_ML_BLOQUEADA_SE_CONCENTRACAO_NAO_CONFIRMADA
- USO_PROLONGADO_MAIOR_5_7_DIAS_EXIGE_ALERTA_FETAL_NEONATAL
Pendencias: 1
- Regime de neuroproteção varia entre protocolos; médico deve validar contexto.

## terbutalina_iv
Bloqueios: 3
- DURACAO_MAIOR_48H_BLOQUEADA
- CARDIOPATIA_RISCO_CARDIACO_IMPORTANTE_BLOQUEIAM_TOCOLISE
- USO_SEM_MONITORIZACAO_MATERNO_FETAL_BLOQUEADO
Pendencias: 1
- Disponibilidade/formulação IV obstétrica AR/BR não confirmada; WHO prefere nifedipina.

## colagenase
Bloqueios: 2
- PEDIATRIA_AUTOMATICA_BLOQUEADA
- VIA_NAO_TOPICA_BLOQUEADA
Pendencias: 1
- Disponibilidade AR/BR não confirmada; futura entrada colagenase_pomada marcada como possível duplicata.

## lidocaina_gel
Bloqueios: 2
- CALCULO_PEDIATRICO_BLOQUEADO_SEM_DOSE_TOTAL_DE_LIDOCAINA_E_INDICACAO
- VIA_OCULAR_E_INJETAVEL_BLOQUEADAS
Pendencias: 1
- Apresentação AR/BR não confirmada.
