# MEDCASES GOLD33 - LOTE 090 - REFERENCIAS

Parecer: Dra Eugenia Marques | 20-09-2026 | APROVADO INTEGRALMENTE | Arquivo revisado: 090

## betametasona_obstetricia
- 1. WHO 2022 — Antenatal corticosteroids for improving preterm birth outcomes. https://www.who.int/publications/i/item/9789240057296
- 2. DailyMed — CELESTONE SOLUSPAN betamethasone acetate + sodium phosphate injectable suspension, 6 mg/mL, effective 2026-03-06. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=bf78d1be-42d7-4837-92a5-49113a79278f

## ergometrina
- 1. emc SmPC — Ergometrine Injection BP 0.05% w/v, updated 2026-05-05. https://www.medicines.org.uk/emc/product/6265/smpc
- 2. WHO 2025 — Consolidated guidelines for prevention, diagnosis and treatment of postpartum haemorrhage. https://www.ncbi.nlm.nih.gov/books/NBK619233/

## labetalol_iv
- 1. DailyMed — Labetalol Hydrochloride Injection 5 mg/mL, label updated 2026-03-03. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=d7c53b1c-b6a5-482a-a7c8-7425d9cd9ef8
- 2. AHA/ACC 2025 hypertension guideline — pregnancy tables incorporating ACOG urgent BP control regimens. https://www.ahajournals.org/doi/full/10.1161/CIR.0000000000001356

## misoprostol_obstetrico
- 1. WHO 2025 maternal health recommendations — induction of labour. https://www.ncbi.nlm.nih.gov/books/NBK615641/
- 2. WHO 2025 PPH guideline — treatment with sublingual misoprostol 800 mcg when IV oxytocin unavailable/nonresponsive. https://www.ncbi.nlm.nih.gov/books/NBK619233/
- 3. DailyMed — CYTOTEC misoprostol, updated 2026-05-22; PK/reference product, obstetric regimens are guideline-based/off-label in US label. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=4ab12da7-5731-4e06-bf1c-bc3f2e711f12

## nifedipina_retard
- 1. DailyMed — Nifedipine extended-release tablets 30/60/90 mg, updated 2026-04-15. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=4d02eba2-e964-4fa7-aaae-25949b5f0316
- 2. AHA/ACC 2025 hypertension guideline — pregnancy: extended-release nifedipine 30–120 mg/day. https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007
- 3. WHO 2022 — tocolytic therapy; preferred nifedipine regimen uses immediate-release, not retard. https://www.who.int/publications/i/item/9789240057227

## ocitocina_iv
- 1. DailyMed — Oxytocin Injection 10 units/mL, effective 2026-01-12. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=c7fd585a-99b7-4309-b003-a6cbef05372c
- 2. WHO 2025 — PPH prevention/treatment recommendations. https://www.ncbi.nlm.nih.gov/books/NBK619233/

## sulfato_de_magnesio_obstetricia
- 1. DailyMed — Magnesium Sulfate Injection 50%, updated 2026-01-08. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=6a5d362b-7aa7-40d3-898d-09407cce0713
- 2. NICE NG133 — Hypertension in pregnancy; eclampsia regimen. https://www.nice.org.uk/guidance/ng133/chapter/recommendations
- 3. WHO 2025 maternal health recommendations — magnesium sulfate neuroprotection/preterm birth evidence. https://www.ncbi.nlm.nih.gov/books/NBK615643/

## terbutalina_iv
- 1. emc SmPC — Bricanyl Injection 0.5 mg/mL solution for injection or infusion. https://www.medicines.org.uk/emc/product/867/smpc
- 2. WHO 2022 — tocolytic therapy: nifedipine preferred; betamimetics have serious maternal adverse-effect risk. https://www.ncbi.nlm.nih.gov/sites/books/NBK585030/
- 3. DailyMed — Terbutaline sulfate injection boxed warning; US product is SC and not approved for prolonged tocolysis. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=5d79e3a0-a83e-4406-b792-99857ba91840

## colagenase
- 1. DailyMed — COLLAGENASE SANTYL ointment 250 units/g, BLA101995. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=6b6fbfc6-98fa-46aa-88ef-ab00fbb08ffd

## lidocaina_gel
- 1. DailyMed — Lidocaine HCl Jelly 2%, effective 2026-08-12. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=9b2d4f69-0c84-4956-b5c0-b4410acf62e0
- 2. DailyMed — GLYDO lidocaine HCl jelly 2%, updated 2026-02-04. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=65760723-75cd-472c-96e1-7d05f95b4686
