# Referencias - Lote 103 homologado

## adrenalina_autoinjetavel
- DailyMed/NLM EUA - AUVI-Q, label revised 04/2025. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=6180fb40-7fca-4602-b3da-ce62b8cd2470
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=6180fb40-7fca-4602-b3da-ce62b8cd2470
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=6180fb40-7fca-4602-b3da-ce62b8cd2470

## aminofilina_iv
- DailyMed/NLM EUA - Aminophylline Injection USP 25 mg/mL, updated 22-05-2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=9a663ef3-881f-48bd-2689-3713b24545c2
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=9a663ef3-881f-48bd-2689-3713b24545c2
- ref.es: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=9a663ef3-881f-48bd-2689-3713b24545c2

## betametasona_injetavel
- DailyMed/NLM EUA - Betamethasone Sodium Phosphate + Acetate Injectable Suspension 6 mg/mL, current label 2025/2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=be3e57df-339a-4b7c-9528-d478af8c7855
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=be3e57df-339a-4b7c-9528-d478af8c7855
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=be3e57df-339a-4b7c-9528-d478af8c7855

## brometo_de_ipratropio_nebulizacao
- DailyMed/NLM EUA - Ipratropium Bromide Inhalation Solution 0.02%, active 2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3249aea8-a395-f09f-e063-6294a90a2d8b
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3249aea8-a395-f09f-e063-6294a90a2d8b
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3249aea8-a395-f09f-e063-6294a90a2d8b

## dexametasona_iv
- DailyMed/NLM EUA - Dexamethasone Sodium Phosphate Injection, current 2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0277cc0a-2fd4-4605-a310-b613be84ee26
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0277cc0a-2fd4-4605-a310-b613be84ee26
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0277cc0a-2fd4-4605-a310-b613be84ee26

## fenoterol_gotas
- ANVISA/CMED - listagem de precos 2026 contendo bromidrato de fenoterol 5 mg/mL gotas/BEROTEC. https://www.gov.br/anvisa/pt-br/assuntos/medicamentos/cmed/precos/anos-anteriores/arquivos/5333json-file-1/%40%40download/file
- Bula profissional historica do bromidrato de fenoterol, hospedada por consorcio publico; usada apenas para sinais farmacologicos/interacoes, nao para liberar dose atual. https://www.conims.pr.gov.br/arquivo_usu/documentoanexo/conims-20200828-140719.pdf
- ref.pt: https://www.gov.br/anvisa/pt-br/assuntos/medicamentos/cmed/precos/anos-anteriores/arquivos/5333json-file-1/%40%40download/file
- ref.es: https://www.gov.br/anvisa/pt-br/assuntos/medicamentos/cmed/precos/anos-anteriores/arquivos/5333json-file-1/%40%40download/file

## hidrocortisona_iv
- DailyMed/NLM EUA - Hydrocortisone Sodium Succinate for Injection 100 mg, updated 08-05-2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=37534164-9de5-4bb3-9f87-341dfcf90883
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=37534164-9de5-4bb3-9f87-341dfcf90883
- ref.es: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=37534164-9de5-4bb3-9f87-341dfcf90883

## metilprednisolona_iv
- DailyMed/NLM EUA - SOLU-MEDROL, current label revised 11/2025, active 2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=cd99be87-c8d9-48d6-a8e5-e081052e3f19
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=cd99be87-c8d9-48d6-a8e5-e081052e3f19
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=cd99be87-c8d9-48d6-a8e5-e081052e3f19

## prometazina_im
- DailyMed/NLM EUA - Promethazine Hydrochloride Injection 25 mg/mL, current label 2024/2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=b0d5abba-6fae-4f3c-b990-dd9c83c7b5a9
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=b0d5abba-6fae-4f3c-b990-dd9c83c7b5a9
- ref.es: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=b0d5abba-6fae-4f3c-b990-dd9c83c7b5a9

## salbutamol_nebulizacao
- DailyMed/NLM EUA - Albuterol Sulfate Inhalation Solution 0.083% 2.5 mg/3 mL, active 2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=b72742df-1a6b-4483-aff3-3e79db5e015d
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=b72742df-1a6b-4483-aff3-3e79db5e015d
- ref.es: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=b72742df-1a6b-4483-aff3-3e79db5e015d

