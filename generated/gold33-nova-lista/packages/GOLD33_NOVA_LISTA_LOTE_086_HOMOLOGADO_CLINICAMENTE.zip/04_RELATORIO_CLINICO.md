# Relatorio clinico - Lote 086

Arquivo revisado no parecer: 003
Lote administrativo atual: 086
Medico revisor: Dra Eugenia Marques
Data: 20-09-2026
Resultado: APROVADO INTEGRALMENTE
Excecoes: nenhuma informada

Conteudo clinico do candidato preservado sem correcoes adicionais.
Bloqueios granulares e pendencias documentadas permanecem preservados para o Codex.
Integracao tecnica e publicacao nao foram executadas.

## ibuprofeno_iv
Bloqueios: nenhum
Pendencias: DIRETRIZ_INDEPENDENTE_NAO_VALIDADA; DISPONIBILIDADE_BR_AR_NAO_VALIDADA

## parecoxibe
Bloqueios: CALCULO_PEDIATRICO_BLOQUEADO: seguranca/eficacia <18 anos nao estabelecidas.
Pendencias: DIRETRIZ_INDEPENDENTE_NAO_VALIDADA; DISPONIBILIDADE_BR_AR_NAO_VALIDADA

## tenoxicam
Bloqueios: CALCULO_PEDIATRICO_BLOQUEADO: nao ha posologia estabelecida.
Pendencias: DIRETRIZ_INDEPENDENTE_NAO_VALIDADA; DISPONIBILIDADE_BR_AR_NAO_VALIDADA

## tramadol_paracetamol
Bloqueios: CALCULO_PEDIATRICO_BLOQUEADO: seguranca/eficacia nao estabelecidas e existem contraindicacoes etarias.
Pendencias: DIRETRIZ_INDEPENDENTE_NAO_VALIDADA; DISPONIBILIDADE_BR_AR_NAO_VALIDADA

## agua_para_injecao
Bloqueios: ADMINISTRACAO_DIRETA_IV_BLOQUEADA: bula proibe infusao isolada por hipotonicidade.; CALCULO_DE_DOSE_PROPRIA_BLOQUEADO: nao existe dose terapeutica propria; volume depende do medicamento
Pendencias: DIRETRIZ_INDEPENDENTE_NAO_APLICAVEL/NAO_VALIDADA

## aminoacidos_parenterais
Bloqueios: FORMULACAO_GENERICA_BLOQUEADA: "aminoacidos parenterais" nao define composicao/concentracao unica; dados; CALCULO_PEDIATRICO_BLOQUEADO: rotulo antigo cita 2-3 g/kg/dia em lactentes, mas declara ausencia de estudos; INFUSAO_DIRETA_DO_PBP_BLOQUEADA: produto e somente para manipulacao de misturas.
Pendencias: DIRETRIZ_NUTRICAO_PARENTERAL_CONTEMPORANEA_NAO_VALIDADA; DISPONIBILIDADE_BR_AR_NAO_VALIDADA

## cloreto_de_potassio_19_1
Bloqueios: CALCULO_PEDIATRICO_BLOQUEADO: bula rotula uso pediatrico, mas nao fornece dose universal por kg.
Pendencias: DIRETRIZ_INDEPENDENTE_NAO_VALIDADA

## cloreto_de_sodio_20
Bloqueios: CALCULO_DE_DOSE_BLOQUEADO: bula nao define esquema universal em mL/mEq.; INFUSAO_AUTOMATICA_BLOQUEADA: nao ha velocidade universal; exige protocolo por indicacao/alvo.; CALCULO_PEDIATRICO_BLOQUEADO: uso pediatrico rotulado, sem dose universal por kg.
Pendencias: DIRETRIZ_INDEPENDENTE_NAO_VALIDADA

## emulsao_lipidica_parenteral
Bloqueios: nenhum
Pendencias: DIRETRIZ_NUTRICAO_PARENTERAL_CONTEMPORANEA_NAO_VALIDADA; DISPONIBILIDADE_BR_AR_NAO_VALIDADA

## glicerina_supositorio
Bloqueios: nenhum
Pendencias: DIRETRIZ_INDEPENDENTE_NAO_VALIDADA; DISPONIBILIDADE_BR_AR_NAO_VALIDADA
