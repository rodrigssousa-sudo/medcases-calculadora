# Referencias - GOLD33 NOVA LISTA LOTE 086

Parecer clinico: Dra Eugenia Marques, 20-09-2026, aprovado integralmente, sem excecoes.

## ibuprofeno_iv
- DailyMed/FDA - CALDOLOR (ibuprofen injection) prescribing information | EUA; IV; label version 16, revisado 02/2025; adultos e pediatria >=3 meses | Consultado 2026-09-20 | https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=1eaa7790-f1a1-4f51-b10a-cbbaf033f684&version=16

## parecoxibe
- EMA - Dynastat (parecoxib) EPAR Product Information | UE; po 40 mg para solucao IV/IM; informacao atualizada 05/03/2025 | Consultado 2026-09-20 | https://www.ema.europa.eu/en/documents/product-information/dynastat-epar-product-information_en.pdf

## tenoxicam
- Medsafe NZ - Tilcotil 20 mg tablets Data Sheet | Nova Zelandia; comprimido 20 mg; data sheet 20/11/2025 | Consultado 2026-09-20 | https://www.medsafe.govt.nz/profs/datasheet/t/Tilcotiltab.pdf

## tramadol_paracetamol
- DailyMed/FDA - Tramadol hydrochloride and acetaminophen tablets 37.5/325 mg | EUA; comprimido oral; revisado 11/2025 | Consultado 2026-09-20 | https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=cb05d615-918d-8104-e053-2995a90aa96b

## agua_para_injecao
- Halex Istar - Isofarma Agua para injecao - bula profissional | Brasil; ampolas 5/10/20 mL; uso como diluente; bulário do fabricante consultado | Consultado 2026-09-20 | https://halexistar.com.br/wp-content/uploads/2025/10/2-844106.pdf

## aminoacidos_parenterais
- DailyMed - 15% CLINISOL sulfite-free Amino Acid Injection Pharmacy Bulk Package | EUA; 15% amino acids; rotulo atualizado 13/06/2014, consultado no DailyMed atual | Consultado 2026-09-20 | https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=65ffc962-7538-41ea-9afb-4af5fbce4c5b

## cloreto_de_potassio_19_1
- Halex Istar - Isofarma solucao de cloreto de potassio 191 mg/mL - bula profissional | Brasil; 19,1%; ampola 10 mL; IV apos diluicao; adulto e pediatrico | Consultado 2026-09-20 | https://halexistar.com.br/wp-content/uploads/2025/10/2-191711617.pdf

## cloreto_de_sodio_20
- Halex Istar - Isofarma solucao de cloreto de sodio 100/200 mg/mL - bula profissional | Brasil; ficha focada em 200 mg/mL (20%), ampola 10 mL; IV apos diluicao | Consultado 2026-09-20 | https://halexistar.com.br/wp-content/uploads/2025/10/2-1261705.pdf

## emulsao_lipidica_parenteral
- DailyMed/FDA - INTRALIPID 20% I.V. Fat Emulsion | EUA; emulsao lipidica 20%; revisado 08/2025 | Consultado 2026-09-20 | https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=61e025f1-a38e-4af2-9e18-13ea12977cf5

## glicerina_supositorio
- DailyMed - Glycerin suppository 2 g (adult/6+) | EUA OTC; retal; 2 g | Consultado 2026-09-20 | https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=db539b39-9504-44d2-9bd5-ba6ffb441024
- DailyMed - Glycerin Children suppository 1.2 g | EUA OTC; retal; 1,2 g; atualizado 09/2025 | Consultado 2026-09-20 | https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=80a5a944-2882-4f8d-a955-ef827cead5f0
