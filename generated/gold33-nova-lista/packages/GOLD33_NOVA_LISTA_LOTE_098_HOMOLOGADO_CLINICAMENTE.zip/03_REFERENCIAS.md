# Referencias - Lote 098 homologado

## insulina_regular
- DailyMed/NLM EUA - HUMULIN R U-100, efetivo 16-06-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b519bd83-038c-4ec5-a231-a51ec5cc291f
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b519bd83-038c-4ec5-a231-a51ec5cc291f
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b519bd83-038c-4ec5-a231-a51ec5cc291f

## insulina_nph_caneta
- DailyMed/NLM EUA - HUMULIN N KwikPen, revisao 19-12-2025. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f6edd793-440b-40c2-96b5-c16133b7a921
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f6edd793-440b-40c2-96b5-c16133b7a921
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f6edd793-440b-40c2-96b5-c16133b7a921

## levotiroxina_sodica
- DailyMed/NLM EUA - Levothyroxine Sodium tablets, PI 02/2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=d9dff641-ced3-bae3-e053-2a95a90a2e29
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=d9dff641-ced3-bae3-e053-2a95a90a2e29
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=d9dff641-ced3-bae3-e053-2a95a90a2e29

## tiamazol
- DailyMed/NLM EUA - Methimazole tablets, atualizado 09-09-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f69edfa9-0efb-4fe8-aeab-50f7baeebb6a
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f69edfa9-0efb-4fe8-aeab-50f7baeebb6a
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f69edfa9-0efb-4fe8-aeab-50f7baeebb6a

## amitriptilina_comprimido
- DailyMed/NLM EUA - Amitriptyline tablets, atualizado 08-09-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=4e520c63-1cf6-40f6-a51c-3f9b0e181342
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=4e520c63-1cf6-40f6-a51c-3f9b0e181342
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=4e520c63-1cf6-40f6-a51c-3f9b0e181342

## nortriptilina_comprimido
- UK eMC - Nortriptyline 10 mg Film-Coated Tablets, SmPC. https://www.medicines.org.uk/emc/product/13516/smpc
- ref.pt: https://www.medicines.org.uk/emc/product/13516/smpc
- ref.es: https://www.medicines.org.uk/emc/product/13516/smpc

## fluoxetina_comprimido
- DailyMed/NLM EUA - Fluoxetine tablets, atualizado 05-06-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=53ac797d-8792-4a8c-9708-d1de3d377e8f
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=53ac797d-8792-4a8c-9708-d1de3d377e8f
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=53ac797d-8792-4a8c-9708-d1de3d377e8f

## sertralina_comprimido
- DailyMed/NLM EUA - Sertraline tablets, atualizado 15-07-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f6346a11-88b9-4425-b08d-a22f19c4ceb4
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f6346a11-88b9-4425-b08d-a22f19c4ceb4
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f6346a11-88b9-4425-b08d-a22f19c4ceb4

## escitalopram_comprimido
- DailyMed/NLM EUA - Escitalopram tablets, atualizado 20-05-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=155e973a-f4ff-4e5a-b937-09f1e106fe39
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=155e973a-f4ff-4e5a-b937-09f1e106fe39
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=155e973a-f4ff-4e5a-b937-09f1e106fe39

## clonazepam_gotas
- ANMAT Argentina - Disposicion 4335/2022, CLONAGIN 2,5 mg/mL gotas. https://boletin.anmat.gob.ar/Mayo_2022/Dispo_4335-22.pdf
- AEMPS/CIMA - Rivotril 2,5 mg/mL gotas, controle cruzado de concentracao/dispositivo. https://cima.aemps.es/cima/dochtml/ft/52401/FT_52401.html
- ref.pt: https://boletin.anmat.gob.ar/Mayo_2022/Dispo_4335-22.pdf
- ref.es: https://boletin.anmat.gob.ar/Mayo_2022/Dispo_4335-22.pdf

