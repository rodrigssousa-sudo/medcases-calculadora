# Referencias - GOLD33 Nova Lista Lote 084

Revisao medica: Dra Ariani | 20-09-2026 | Aprovado integralmente

## capecitabina
- DailyMed - Capecitabine tablets, USP - full prescribing information | Revised 06/2026 | EUA; comprimido oral 500 mg; rotulo regulatorio do produto consultado | Consultado 2026-09-20 | https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=d23f023a-ea62-4ac0-f615-d5d26d59526d

## doxorrubicina
- DailyMed - Doxorubicin Hydrochloride Injection - full prescribing information | Updated 05/05/2026 | EUA; doxorrubicina convencional IV 2 mg/mL; nao lipossomal | Consultado 2026-09-20 | https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1fd148fb-0fbc-4b6f-b790-23546fb46a71

## fluorouracila
- DailyMed - Fluorouracil Injection, USP - full prescribing information | Updated 14/08/2026 | EUA; fluorouracil IV 50 mg/mL | Consultado 2026-09-20 | https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=f0b60247-89ff-42b5-a55b-61980c282749

## imatinibe
- DailyMed - Imatinib Mesylate tablets - full prescribing information | Revised 09/2026 | EUA; comprimidos 100 mg e 400 mg | Consultado 2026-09-20 | https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0291eca5-7a1d-4a79-30be-252224d96509

## leuprorrelina
- DailyMed - LUPRON DEPOT (leuprolide acetate for depot suspension) - full prescribing information | Updated 15/03/2026 | EUA; formulacoes depot IM 1, 3, 4 e 6 meses para cancer de prostata avancado | Consultado 2026-09-20 | https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=cbc8f94e-7330-4465-05ad-16d64493a5dd
- ANVISA - Denominacoes Comuns Brasileiras (DCB) - pagina institucional | Acesso 2026 | Identidade nomenclatural; nao usada como fonte de dose | Consultado 2026-09-20 | https://www.gov.br/anvisa/pt-br/assuntos/farmacopeia/dcb

## paclitaxel
- DailyMed - Paclitaxel Injection USP - full prescribing information | Effective 11/07/2026 | EUA; paclitaxel convencional 6 mg/mL com polyoxyl 35 castor oil e alcool; nao albumina-bound | Consultado 2026-09-20 | https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=fbd32bd2-9685-41cb-bee2-730a45526b65

## tamoxifeno
- DailyMed - Tamoxifen Citrate tablets - full prescribing information | Updated 30/04/2026 | EUA; comprimidos 10 mg e 20 mg | Consultado 2026-09-20 | https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=509f8ba3-214d-aec8-e063-6294a90af498&version=2

## trastuzumabe
- DailyMed - HERCEPTIN (trastuzumab) for injection - full prescribing information | Revised 05/2026 | EUA; trastuzumabe IV 150 mg; nao SC e nao conjugados | Consultado 2026-09-20 | https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=492dbdb2-077e-4064-bff3-372d6af0a7a2

## vincristina
- DailyMed - Vincristine Sulfate Injection, USP - full prescribing information | Effective 17/02/2026 | EUA; solucao IV 1 mg/mL; intratecal fatal | Consultado 2026-09-20 | https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b22e4c8e-dbe1-4d4b-a026-e1812974071c

## alizaprida
- Base de Donnees Publique des Medicaments - PLITICAN 50 mg/2 mL, solution injectable - RCP | RCP mise a jour 01/07/2023; base consultada 2026 | Franca; adulto; IM/IV; produto com comercializacao declarada encerrada em 06/03/2026 | Consultado 2026-09-20 | https://m.base-donnees-publique.medicaments.gouv.fr/rcp-68650684-10
- Base de Donnees Publique des Medicaments - extrait PLITICAN injectable | Base atualizada 31/08/2026 | Franca; status de apresentacao/comercializacao | Consultado 2026-09-20 | https://base-donnees-publique.medicaments.gouv.fr/medicament/68650684/extrait
