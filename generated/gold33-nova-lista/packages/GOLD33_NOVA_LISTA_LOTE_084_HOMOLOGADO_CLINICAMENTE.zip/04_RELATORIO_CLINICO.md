# Relatorio clinico homologado - Lote 084

- Lista: NOVA_LISTA_GOLD33_V1
- Medicamentos: 10/10
- Medico revisor: Dra Ariani
- Data: 20-09-2026
- Resultado: Aprovado integralmente
- Excecoes: nenhuma informada
- Origem: NEW_ENTRY_NO_LEGACY_BASELINE
- Integracao tecnica: NAO EXECUTADA
- Publicacao: BLOQUEADA ate Codex/autorizacao especifica

## Medicamentos
- capecitabina
- doxorrubicina
- fluorouracila
- imatinibe
- leuprorrelina
- paclitaxel
- tamoxifeno
- trastuzumabe
- vincristina
- alizaprida

## Decisao
O parecer foi aplicado fielmente. Como nao foram informadas correcoes ou excecoes, o conteudo clinico candidato foi preservado sem alteracoes.
