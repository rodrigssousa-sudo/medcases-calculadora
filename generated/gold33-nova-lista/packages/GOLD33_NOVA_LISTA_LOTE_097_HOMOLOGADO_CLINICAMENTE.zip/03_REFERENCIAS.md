# Referencias - Lote 097 homologado

## propranolol_comprimido
- DailyMed/NLM EUA - Propranolol Hydrochloride tablets, atualizado 15-01-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b94dcec7-7633-4a33-9cea-48161adeaf93
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b94dcec7-7633-4a33-9cea-48161adeaf93
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b94dcec7-7633-4a33-9cea-48161adeaf93

## carvedilol_comprimido
- DailyMed/NLM EUA - Carvedilol tablets, revisado 04/2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=fe2d5c95-c101-4b01-89fd-0fd6d25ad80b
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=fe2d5c95-c101-4b01-89fd-0fd6d25ad80b
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=fe2d5c95-c101-4b01-89fd-0fd6d25ad80b

## espironolactona_comprimido
- DailyMed/NLM EUA - Spironolactone tablets, atualizado 01-01-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=768563dc-a619-44dc-b97f-1a7e71fd56a0
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=768563dc-a619-44dc-b97f-1a7e71fd56a0
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=768563dc-a619-44dc-b97f-1a7e71fd56a0

## furosemida_comprimido
- DailyMed/NLM EUA - Furosemide tablets, atualizado 18-06-2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=2a5bcf50-6d63-463a-915e-a72ea2e5f131
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=2a5bcf50-6d63-463a-915e-a72ea2e5f131
- ref.es: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=2a5bcf50-6d63-463a-915e-a72ea2e5f131

## isossorbida_mononitrato
- DailyMed/NLM EUA - Isosorbide Mononitrate Extended-Release tablets, atualizado 11-05-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0a1e317a-7b05-4d30-9bbc-1d4ccd56ba3c
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0a1e317a-7b05-4d30-9bbc-1d4ccd56ba3c
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0a1e317a-7b05-4d30-9bbc-1d4ccd56ba3c

## isossorbida_dinitrato
- DailyMed/NLM EUA - Isosorbide Dinitrate immediate-release tablets, atualizado 05-01-2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=b166eb5b-bad8-4663-9c05-1c43539dab2c
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=b166eb5b-bad8-4663-9c05-1c43539dab2c
- ref.es: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=b166eb5b-bad8-4663-9c05-1c43539dab2c

## glibenclamida
- DailyMed/NLM EUA - Glyburide tablets, atualizado 18-05-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=9cdd30e7-512a-4f00-a4de-0a154d143ce9
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=9cdd30e7-512a-4f00-a4de-0a154d143ce9
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=9cdd30e7-512a-4f00-a4de-0a154d143ce9

## gliclazida_mr
- UK eMC - Xywin 30 mg Prolonged-release Tablets Gliclazide, SmPC; pagina atualizada 02-06-2026, texto revisado 27-06-2025. https://www.medicines.org.uk/emc/product/102251/smpc
- ref.pt: https://www.medicines.org.uk/emc/product/102251/smpc
- ref.es: https://www.medicines.org.uk/emc/product/102251/smpc

## metformina_comprimido
- DailyMed/NLM EUA - Metformin Hydrochloride immediate-release tablets, atualizado 21-08-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=4e4c4ba9-65c6-4273-8f6b-2423ab521dad
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=4e4c4ba9-65c6-4273-8f6b-2423ab521dad
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=4e4c4ba9-65c6-4273-8f6b-2423ab521dad

## metformina_xr
- DailyMed/NLM EUA - Metformin Hydrochloride Extended-Release tablets, atualizado 09-09-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=2a84c550-aed8-4058-961f-351a5e4cf7a1
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=2a84c550-aed8-4058-961f-351a5e4cf7a1
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=2a84c550-aed8-4058-961f-351a5e4cf7a1

