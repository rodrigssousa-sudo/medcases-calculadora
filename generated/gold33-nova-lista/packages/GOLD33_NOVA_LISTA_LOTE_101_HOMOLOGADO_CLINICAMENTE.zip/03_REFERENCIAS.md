# Referencias - Lote 101 homologado

## colistimetato_sodico
- DailyMed/NLM EUA - Colistimethate for Injection, label atualizado 26-03-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8ec7dc90-825c-422e-9f4b-c8ace9d93af5
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8ec7dc90-825c-422e-9f4b-c8ace9d93af5
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8ec7dc90-825c-422e-9f4b-c8ace9d93af5

## delamanida
- EMA - Deltyba EPAR, product information updated 18-03-2026. https://www.ema.europa.eu/en/medicines/human/EPAR/deltyba
- ref.pt: https://www.ema.europa.eu/en/medicines/human/EPAR/deltyba
- ref.es: https://www.ema.europa.eu/en/medicines/human/EPAR/deltyba

## etionamida
- DailyMed/NLM EUA - TRECATOR 250 mg, label current through 2025/2026. https://dailymed.nlm.nih.gov/dailymed/downloadpdffile.cfm?setId=04a413fe-95f4-47a7-42ac-283a9e78297d
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/downloadpdffile.cfm?setId=04a413fe-95f4-47a7-42ac-283a9e78297d
- ref.es: https://dailymed.nlm.nih.gov/dailymed/downloadpdffile.cfm?setId=04a413fe-95f4-47a7-42ac-283a9e78297d

## flucitosina
- DailyMed/NLM EUA - ANCOBON, Rev 02/2022. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=aea0df00-a88c-4a16-abcf-750f3ff2004e
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=aea0df00-a88c-4a16-abcf-750f3ff2004e
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=aea0df00-a88c-4a16-abcf-750f3ff2004e

## foscarnete_sodico
- DailyMed/NLM EUA - Foscarnet sodium injection, updated 25-06-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b03cbb8e-f555-4ed3-854e-dd962604f144
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b03cbb8e-f555-4ed3-854e-dd962604f144
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b03cbb8e-f555-4ed3-854e-dd962604f144

## fosfomicina_iv
- eMC UK - Fomicyt 40 mg/mL SmPC, last updated 16-01-2025. https://www.medicines.org.uk/emc/product/100356/smpc
- ref.pt: https://www.medicines.org.uk/emc/product/100356/smpc
- ref.es: https://www.medicines.org.uk/emc/product/100356/smpc

## letermovir
- DailyMed/NLM EUA - PREVYMIS, updated 14-01-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1b49df80-be4f-47e0-a0b7-123f3e69395b
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1b49df80-be4f-47e0-a0b7-123f3e69395b
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1b49df80-be4f-47e0-a0b7-123f3e69395b

## mefloquina
- DailyMed/NLM EUA - Mefloquine Hydrochloride Tablets, updated 26-09-2025. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=09716a24-d7da-42b2-af29-c03a1b6670bd
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=09716a24-d7da-42b2-af29-c03a1b6670bd
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=09716a24-d7da-42b2-af29-c03a1b6670bd

## nifurtimox
- DailyMed/NLM EUA - LAMPIT, effective 03-03-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=90d09714-a8b1-4696-8ada-f99dc54d0721
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=90d09714-a8b1-4696-8ada-f99dc54d0721
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=90d09714-a8b1-4696-8ada-f99dc54d0721

## palivizumabe
- DailyMed/NLM EUA - SYNAGIS, effective 21-01-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3a0096c7-8139-44cd-bba4-520ab05c2cb2
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3a0096c7-8139-44cd-bba4-520ab05c2cb2
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3a0096c7-8139-44cd-bba4-520ab05c2cb2

