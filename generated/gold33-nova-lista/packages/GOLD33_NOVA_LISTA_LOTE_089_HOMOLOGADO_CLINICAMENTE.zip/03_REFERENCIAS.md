# MEDCASES GOLD33 - LOTE 089 - REFERENCIAS

Parecer: Dra Eugenia Marques | 20-09-2026 | APROVADO INTEGRALMENTE | Arquivo revisado: 089

## fibrinogenio_humano
- DailyMed/FDA — RIASTAP, Fibrinogen Concentrate (Human), CSL Behring; label updated 29-12-2025, major change 12/2025; IV, congenital fibrinogen deficiency, dose/reconstitution/safety; consulted 20-09-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=903dc8d0-39da-462c-9dac-004e0c7a26cc

## fitomenadiona_vitamina_k_iv
- DailyMed/FDA — Vitamin K1 (phytonadione) Injection, emulsion; label updated 25-05-2026; boxed warning for IV/IM hypersensitivity, dosing, neonatal use and administration; consulted 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=e8808230-2c44-44c6-8cab-8f29b6b34051

## plasma_fresco_congelado
- AABB/American Red Cross/America’s Blood Centers/Armed Services Blood Program — Circular of Information for the Use of Human Blood and Blood Components, June 2024; plasma components, indications, pediatric dosing and transfusion hazards; consulted 20-09-2026. https://www.aabb.org/docs/default-source/default-document-library/resources/circular-of-information-watermark.pdf
- FDA — Guidance for Industry: An Acceptable Circular of Information for the Use of Human Blood and Blood Components, September 2024; recognizes June 2024 Circular; consulted 20-09-2026. https://www.fda.gov/regulatory-information/search-fda-guidance-documents/acceptable-circular-information-use-human-blood-and-blood-components

## biperideno_im
- Cristália — CINETOL (lactato de biperideno) 5 mg/mL solução injetável, bula profissional; IM/IV, contraindicações, interações and posology; current manufacturer PDF consulted 20-09-2026. https://cristalia.com.br/produto/64/bula-profissional

## clorpromazina_im
- DailyMed/FDA — Chlorpromazine Hydrochloride Injection, USP 25 mg/mL; current DailyMed label, deep IM route and dosing; consulted 20-09-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=c0f1fcfd-8863-4032-bf80-185df60a4ba0

## diazepam_iv
- DailyMed/FDA — Diazepam Injection, USP 5 mg/mL, Hospira; current DailyMed page, label revised April 2023; IV/IM dosing, status epilepticus, administration and warnings; consulted 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=7e7dd743-a87b-4ab3-b6ae-f116cd0c8b0f

## haloperidol_im
- DailyMed/FDA — Haloperidol lactate injection 5 mg/mL, immediate release; label updated 12-03-2026; IM dose and safety; consulted 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=e702b2f0-d464-41c3-977a-d37bb22c0ab0

## midazolam_im
- DailyMed/FDA — Midazolam Injection, USP; label updated 12-08-2026; IM/IV, adult and pediatric premedication, monitoring and respiratory warnings; consulted 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=b95415fa-17c2-42ab-a6b0-e628d01c94ed

## olanzapina_im
- DailyMed/FDA — Olanzapine for Injection 10 mg/vial, Hikma; label updated 25-08-2026; acute agitation, IM dosing, reconstitution and safety; consulted 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=63bcfe98-d1fc-4cd7-9212-f59ee4dcc6d1

## ziprasidona_im
- DailyMed/FDA — Ziprasidone Mesylate for Injection; label updated 16-09-2025, recent major changes 01/2025; IM dose, reconstitution, QT/renal warnings; consulted 20-09-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1ffd16c3-25ac-4839-9ea9-4efd32926b95
