# RELATORIO CLINICO - LOTE 089

- Medico revisor: Dra Eugenia Marques
- Data: 20-09-2026
- Resultado: APROVADO INTEGRALMENTE
- Excecoes: nenhuma
- Conteudo clinico alterado apos parecer: NAO
- Bloqueios granulares: preservados
- Integracao tecnica: NAO INICIADA
- Publicacao: BLOQUEADA

## fibrinogenio_humano
Bloqueios: 2
- CALCULO_AUTOMATICO_CONDICIONAL: bloquear se não houver peso, fibrinogênio basal/alvo e potência real do frasco.
- USO_ADQUIRIDO_NAO_LIBERADO: a bula consultada cobre deficiência congênita, não coagulopatia adquirida.
Pendencias: 2
- Disponibilidade/registro local AR/BR não confirmados nesta execução.
- Diretriz independente para hemorragia adquirida não incorporada.

## fitomenadiona_vitamina_k_iv
Bloqueios: 2
- VIA_IV_RESTRITA: usar IV somente quando SC não for viável e o risco justificar, por boxed warning de anafilaxia.
- NEONATO_IV_AUTOMATICO_BLOQUEADO: a dose neonatal citada é SC/IM, não deve ser convertida para IV.
Pendencias: 2
- Marca/apresentação local AR/BR não confirmada.
- Guideline específico de reversão de VKA não incorporado.

## plasma_fresco_congelado
Bloqueios: 2
- DOSE_ADULTO_AUTOMATICA_BLOQUEADA: não existe regime universal no Circular; depende de indicação e laboratório.
- VELOCIDADE_AUTOMATICA_BLOQUEADA: risco de TACO/TRALI e política transfusional individual.
Pendencias: 2
- Protocolos locais de hemoterapia AR/BR não foram incorporados.
- Volume real por unidade deve vir do rótulo do componente.

## biperideno_im
Bloqueios: 1
- PEDIATRIA_AUTOMATICA_BLOQUEADA: regra mg/kg da bula é atribuída a fonte secundária e convive com limites por idade; exige revisão clínica individual.
Pendencias: 2
- Diretriz independente não incorporada.
- Disponibilidade AR não confirmada.

## clorpromazina_im
Bloqueios: 2
- ESCALADA_EXTREMA_AUTOMATICA_BLOQUEADA: o rótulo contém doses excepcionalmente altas históricas; exigir decisão clínica especializada.
- PEDIATRIA_IM_AUTOMATICA_BLOQUEADA: não há regime único validado para agitação IM pediátrica.
Pendencias: 2
- Bula local AR/BR não confirmada.
- Guideline moderno de agitação não incorporado.

## diazepam_iv
Bloqueios: 2
- PEDIATRIA_AUTOMATICA_RESTRITA_A_STATUS_EPILEPTICUS_3M_17A: outras indicações pediátricas não usar este algoritmo.
- ADMINISTRACAO_IV_EXIGE_MONITORIZACAO_E_RESSUSCITACAO_DISPONIVEL.
Pendencias: 1
- Apresentação/registros AR/BR não confirmados.

## haloperidol_im
Bloqueios: 2
- PEDIATRIA_IM_BLOQUEADA: ensaios controlados não estabeleceram segurança/eficácia.
- VIA_IV_BLOQUEADA: formulação/rotulagem desta ficha é IM.
Pendencias: 2
- Apresentação local AR/BR não confirmada.
- Diretriz independente de agitação não incorporada.

## midazolam_im
Bloqueios: 2
- CONVERSAO_ML_BLOQUEADA_SE_CONCENTRACAO_NAO_CONFIRMADA.
- PEDIATRIA_AUTOMATICA_BLOQUEADA_FORA_DE_PREMEDICACAO_PROCEDIMENTAL: faixa ampla depende da profundidade de sedação.
Pendencias: 1
- Marca/apresentação AR/BR não confirmada.

## olanzapina_im
Bloqueios: 2
- PEDIATRIA_IM_BLOQUEADA: dose segura/eficaz não estabelecida para esta indicação.
- COADMINISTRACAO_BENZODIAZEPINICO_PARENTERAL_BLOQUEADA: risco cardiorrespiratório/sedação excessiva.
Pendencias: 1
- Apresentação/registros AR/BR não confirmados.

## ziprasidona_im
Bloqueios: 3
- PEDIATRIA_IM_BLOQUEADA: dose segura/eficaz não estabelecida.
- QT_GATING_OBRIGATORIO: contraindicações cardíacas e interações QT devem ser avaliadas antes de liberar dose.
- VIA_IV_BLOQUEADA.
Pendencias: 1
- Apresentação/registros AR/BR não confirmados.
