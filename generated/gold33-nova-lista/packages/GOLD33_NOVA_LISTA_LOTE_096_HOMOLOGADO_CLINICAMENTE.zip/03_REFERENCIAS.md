# Referencias - Lote 096 homologado

## diazepam_retal
- DailyMed/NLM EUA — Diazepam Rectal Gel. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b5b17a28-2cab-4c0d-8f9d-7b224e4d0989
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b5b17a28-2cab-4c0d-8f9d-7b224e4d0989
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b5b17a28-2cab-4c0d-8f9d-7b224e4d0989

## midazolam_intranasal
- DailyMed/NLM EUA — NAYZILAM (midazolam nasal spray). https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=2b29422e-54d5-4a49-8522-e9cf752368c3
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=2b29422e-54d5-4a49-8522-e9cf752368c3
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=2b29422e-54d5-4a49-8522-e9cf752368c3

## fenobarbital_gotas
- DailyMed/NLM EUA — Phenobarbital Oral Solution 20 mg/5 mL, Rev. 02/2026. https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=4616303e-1d91-4888-8156-4ae6bd3891b7&version=2
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=4616303e-1d91-4888-8156-4ae6bd3891b7&version=2
- ref.es: https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=4616303e-1d91-4888-8156-4ae6bd3891b7&version=2

## captopril
- DailyMed/NLM EUA — Captopril tablets, updated 14-09-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1395ba5b-2fc9-41ff-9c43-e0740d781dee
- ESC — 2024 Guidelines for Elevated Blood Pressure and Hypertension. https://www.escardio.org/guidelines/clinical-practice-guidelines/all-esc-practice-guidelines/elevated-blood-pressure-and-hypertension/
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1395ba5b-2fc9-41ff-9c43-e0740d781dee
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1395ba5b-2fc9-41ff-9c43-e0740d781dee

## captopril_sublingual
- DailyMed/NLM EUA — Captopril tablets (rota aprovada VO, não SL). https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1395ba5b-2fc9-41ff-9c43-e0740d781dee
- PubMed — Angeli et al. Sublingual captopril vs nifedipine, 1991. https://pubmed.ncbi.nlm.nih.gov/2012448/
- PubMed — Clinical efficacy of sublingual captopril in hypertensive urgency. https://pubmed.ncbi.nlm.nih.gov/19421685/
- AHA Scientific Statement 2024 — Management of Elevated BP in Acute Care. https://www.ahajournals.org/doi/epdf/10.1161/HYP.0000000000000238
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1395ba5b-2fc9-41ff-9c43-e0740d781dee
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1395ba5b-2fc9-41ff-9c43-e0740d781dee

## enalapril_maleato
- DailyMed/NLM EUA — Enalapril Maleate tablets, updated 10-07-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=eee8633b-9d9e-453d-8c6b-8b13c94d2f58
- ESC — 2024 Guidelines. https://www.escardio.org/guidelines/clinical-practice-guidelines/all-esc-practice-guidelines/elevated-blood-pressure-and-hypertension/
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=eee8633b-9d9e-453d-8c6b-8b13c94d2f58
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=eee8633b-9d9e-453d-8c6b-8b13c94d2f58

## hidroclorotiazida_comprimido
- DailyMed/NLM EUA — Hydrochlorothiazide tablets, updated 12-06-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8c868894-667e-4a51-906a-838d63e420ba
- ESC — 2024 Guidelines. https://www.escardio.org/guidelines/clinical-practice-guidelines/all-esc-practice-guidelines/elevated-blood-pressure-and-hypertension/
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8c868894-667e-4a51-906a-838d63e420ba
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8c868894-667e-4a51-906a-838d63e420ba

## losartana_potassica
- DailyMed/NLM EUA — Losartan Potassium tablets, updated 24-06-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=e7f6b25b-ec4c-4c3a-a541-617d2d9ab393
- ESC — 2024 Guidelines. https://www.escardio.org/guidelines/clinical-practice-guidelines/all-esc-practice-guidelines/elevated-blood-pressure-and-hypertension/
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=e7f6b25b-ec4c-4c3a-a541-617d2d9ab393
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=e7f6b25b-ec4c-4c3a-a541-617d2d9ab393

## anlodipino_besilato
- DailyMed/NLM EUA — Amlodipine Besylate tablets, updated 08-06-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3518853a-4c5b-4161-a178-8da7f656f009
- ESC — 2024 Guidelines. https://www.escardio.org/guidelines/clinical-practice-guidelines/all-esc-practice-guidelines/elevated-blood-pressure-and-hypertension/
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3518853a-4c5b-4161-a178-8da7f656f009
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3518853a-4c5b-4161-a178-8da7f656f009

## atenolol_comprimido
- DailyMed/NLM EUA — Atenolol tablets, updated 11-09-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8104a825-a0f1-4383-acbd-83670caee197
- ESC — 2024 Guidelines. https://www.escardio.org/guidelines/clinical-practice-guidelines/all-esc-practice-guidelines/elevated-blood-pressure-and-hypertension/
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8104a825-a0f1-4383-acbd-83670caee197
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=8104a825-a0f1-4383-acbd-83670caee197

