# Referencias - Lote 102 homologado

## pentamidina
- DailyMed/NLM EUA - Pentamidine Isethionate for Injection, atualizado 07-05-2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=d46aea4f-8f3f-4ce0-93d6-94e147f5a31a
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=d46aea4f-8f3f-4ce0-93d6-94e147f5a31a
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=d46aea4f-8f3f-4ce0-93d6-94e147f5a31a

## pirimetamina
- FDA - DARAPRIM label, 2017; pagina avisa que pode nao ser a mais recente. https://www.accessdata.fda.gov/drugsatfda_docs/label/2017/008578s019lbl.pdf
- ref.pt: https://www.accessdata.fda.gov/drugsatfda_docs/label/2017/008578s019lbl.pdf
- ref.es: https://www.accessdata.fda.gov/drugsatfda_docs/label/2017/008578s019lbl.pdf

## primaquina
- DailyMed/NLM EUA - Primaquine Phosphate Tablets, atual em 2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0c8c2bc6-428b-40b6-8114-6df80290878d
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0c8c2bc6-428b-40b6-8114-6df80290878d
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0c8c2bc6-428b-40b6-8114-6df80290878d

## quinupristina_dalfopristina
- FDA - SYNERCID label 2017. https://www.accessdata.fda.gov/drugsatfda_docs/label/2017/050747s015,050748s014lbl.pdf
- ref.pt: https://www.accessdata.fda.gov/drugsatfda_docs/label/2017/050747s015,050748s014lbl.pdf
- ref.es: https://www.accessdata.fda.gov/drugsatfda_docs/label/2017/050747s015,050748s014lbl.pdf

## ribavirina
- DailyMed/NLM EUA - Ribavirin tablets, atual. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=eee304d0-c2ea-44f4-97d9-92a414d31b6c
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=eee304d0-c2ea-44f4-97d9-92a414d31b6c
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=eee304d0-c2ea-44f4-97d9-92a414d31b6c

## sulbactam_iv
- Laboratorios Bago / ANMAT Argentina - Sulbactam Bago 1 g IM/IV, prospecto Disp. 1077/11. https://www.bago.com.ar/wp-content/uploads/2025/12/Sulbactam-Bago-Prospecto-Disp.-1077-11.pdf
- ref.pt: https://www.bago.com.ar/wp-content/uploads/2025/12/Sulbactam-Bago-Prospecto-Disp.-1077-11.pdf
- ref.es: https://www.bago.com.ar/wp-content/uploads/2025/12/Sulbactam-Bago-Prospecto-Disp.-1077-11.pdf

## sulfadiazina
- DailyMed/NLM EUA - Sulfadiazine tablets 500 mg, current label. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=6032d6f7-cbce-4e5d-841c-a1e24b616f91
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=6032d6f7-cbce-4e5d-841c-a1e24b616f91
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=6032d6f7-cbce-4e5d-841c-a1e24b616f91

## taurolidina
- DailyMed/NLM EUA - DEFENCATH, taurolidine/heparin catheter lock, atual 2026. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=13b3a61e-5a4b-4afb-8fa1-d76ebdb344d6
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=13b3a61e-5a4b-4afb-8fa1-d76ebdb344d6
- ref.es: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=13b3a61e-5a4b-4afb-8fa1-d76ebdb344d6

## tecovirimat
- DailyMed/FDA EUA - TPOXX current prescribing information. https://dailymed.nlm.nih.gov/dailymed/fda/fdaDrugXsl.cfm?setid=fce826ab-4d6a-4139-a2ee-a304a913a253
- ref.pt: https://dailymed.nlm.nih.gov/dailymed/fda/fdaDrugXsl.cfm?setid=fce826ab-4d6a-4139-a2ee-a304a913a253
- ref.es: https://dailymed.nlm.nih.gov/dailymed/fda/fdaDrugXsl.cfm?setid=fce826ab-4d6a-4139-a2ee-a304a913a253

## vancomicina_oral
- DailyMed/NLM EUA - Vancomycin Hydrochloride Capsules, active label 17-08-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=bc737938-ae36-460b-a2a8-609f3fe59156
- ref.pt: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=bc737938-ae36-460b-a2a8-609f3fe59156
- ref.es: https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=bc737938-ae36-460b-a2a8-609f3fe59156

