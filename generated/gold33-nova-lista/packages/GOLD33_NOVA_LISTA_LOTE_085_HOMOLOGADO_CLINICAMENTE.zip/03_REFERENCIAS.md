# Referencias - GOLD33 Nova Lista Lote 085

Revisao medica: Dra Eugenia Marques | 20-09-2026 | Aprovado integralmente

## bromoprida
- Eurofarma - Digesan (bromoprida) 10 mg capsula - bula profissional | VPS V01; consultada em 2026 | Brasil; capsula oral 10 mg; uso adulto | Consultado 2026-09-20 | https://bulas.eurofarma.com.br/storage/media/12921/eZ4UciFhY53oJQtpd818OmN22dFlhAywx7NXrvHj.pdf

## butilbrometo_de_escopolamina
- eMC/MHRA - Hyoscine butylbromide 10 mg coated tablets - SmPC | Updated 16 Jun 2026 | Reino Unido; comprimido revestido oral 10 mg | Consultado 2026-09-20 | https://www.medicines.org.uk/emc/product/102336/smpc

## cetorolaco_sublingual
- Eurofarma - trometamol cetorolaco 10 mg sublingual - bula profissional | Bula padrao Anvisa atualizada em 17/06/2021 | Brasil; comprimido sublingual 10 mg; uso adulto | Consultado 2026-09-20 | https://bulas.eurofarma.com.br/storage/media/12636/K4TV2awQ7FS5g0VwqPQvcbYW1DNXux6k1nEKvEDA.pdf

## clonixinato_de_lisina
- ANMAT - Disposicion 3199/2022 - DORIXINA clonixinato de lisina 125 mg | 06/05/2022 | Argentina; comprimido recubierto 125 mg | Consultado 2026-09-20 | https://boletin.anmat.gob.ar/Mayo_2022/Dispo_3199-22.pdf
- ANMAT - Disposicion 3130/2017 - DOLEX clonixinato de lisina 125 mg | 2017 | Argentina; fonte complementar para mecanismo e farmacocinetica | Consultado 2026-09-20 | https://boletin.anmat.gob.ar/marzo_2017/Dispo_3130-17.pdf

## paracetamol_codeina
- DailyMed - Acetaminophen and Codeine Phosphate tablets, USP | Current version Jan 23 2026; label revised 12/2025 | EUA; comprimidos orais 300 mg acetaminophen + 15/30/60 mg codeine phosphate | Consultado 2026-09-20 | https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=297dc9ff-e34f-434b-b1a4-4c995a5bac8b

## dexketoprofeno
- AEMPS CIMA - Dexketoprofeno Aurovitas 25 mg comprimidos - Ficha Tecnica | Revision 02/2026 | Espanha; comprimido oral 25 mg | Consultado 2026-09-20 | https://cima.aemps.es/cima/dochtml/ft/77834/FichaTecnica_77834.html

## diclofenaco_im
- eMC/MHRA - Voltarol Ampoules - SmPC | Last updated 23 Sep 2025; text revision 09 Sep 2025 | UK; diclofenac sodium 75 mg/3 mL; scope IM | Consultado 2026-09-20 | https://www.medicines.org.uk/emc/product/1043/smpc

## dimenidrinato
- AEMPS CIMA - Normostop 50 mg comprimidos - Ficha Tecnica | Ficha tecnica vigente consultada 20/09/2026 | Espanha; dimenhidrinato 50 mg comprimido oral | Consultado 2026-09-20 | https://cima.aemps.es/cima/dochtml/ft/78946/FT_78946.html

## dipirona_iv
- AEMPS CIMA - Metamizol Kalceks 500 mg/mL solucion inyectable - Ficha Tecnica | Revision 04/2025 | Espanha; solucao injetavel 500 mg/mL; escopo IV | Consultado 2026-09-20 | https://cima.aemps.es/cima/dochtml/ft/88385/FT_88385.html
- ANVISA - registro/embalagem de dipirona monoidratada 500 mg/mL injetavel Santisa | Registro BR citado em base regulatoria; confirmar produto especifico antes de integracao | Brasil; corroboracao de concentracao/apresentacao, nao usada para substituir FT AEMPS | Consultado 2026-09-20 | https://consultas.anvisa.gov.br/#/bulario/

## butilbrometo_de_escopolamina_dipirona
- Buscopan Composto - bula aprovada pela Anvisa 02/02/2021 | 11/2020; Anvisa approval 02/02/2021 | Brasil; comprimido revestido oral adulto 10 mg/250 mg | Consultado 2026-09-20 | https://www.buscopan.com.br/assets/files/Bula_Buscopan_Composto.pdf
