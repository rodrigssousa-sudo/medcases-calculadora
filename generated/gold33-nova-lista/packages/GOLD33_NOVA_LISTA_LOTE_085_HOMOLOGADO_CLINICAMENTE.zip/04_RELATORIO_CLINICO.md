# Relatorio clinico homologado - Lote 085

- Lista: NOVA_LISTA_GOLD33_V1
- Medicamentos: 10/10
- Medico revisor: Dra Eugenia Marques
- Data: 20-09-2026
- Resultado: Aprovado integralmente
- Excecoes: nenhuma informada
- Origem: NEW_ENTRY_NO_LEGACY_BASELINE
- Integracao tecnica: NAO EXECUTADA
- Publicacao: BLOQUEADA ate Codex/autorizacao especifica

## Medicamentos
- bromoprida
- butilbrometo_de_escopolamina
- cetorolaco_sublingual
- clonixinato_de_lisina
- paracetamol_codeina
- dexketoprofeno
- diclofenaco_im
- dimenidrinato
- dipirona_iv
- butilbrometo_de_escopolamina_dipirona

## Decisao
O parecer foi aplicado fielmente. Como nao foram informadas correcoes ou excecoes, o conteudo clinico candidato foi preservado sem alteracoes.
