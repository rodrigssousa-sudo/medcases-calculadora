# Lote 106 homologado

- Medico: Dra Eugenia Marques
- Data: 20-09-2026
- Resultado: Aprovado integralmente
- Excecoes: 0
- Alteracoes clinicas: 0
- Integracao: NAO_INICIADA
- Publicacao: BLOQUEADA
