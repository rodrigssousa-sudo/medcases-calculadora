# Referencias - Lote 106 homologado

## ocitocina_iv
- DailyMed/NLM EUA - Oxytocin Injection 10 USP units/mL, updated 01-09-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b6f20a2c-3609-4b09-b8f7-8d8eaeb5c242

## sulfato_de_magnesio_obstetricia
- DailyMed/NLM EUA - Magnesium Sulfate Injection 50%, updated 13-01-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?audience=professional&setid=e921a46b-9a5b-4163-9c88-224247541f14

## terbutalina_iv
- eMC UK - Bricanyl Injection 0.5 mg/mL SmPC. https://www.medicines.org.uk/emc/product/867/smpc

## colagenase
- DailyMed/NLM EUA - Collagenase SANTYL Ointment 250 units/g; active product, label 2019. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=6b6fbfc6-98fa-46aa-88ef-ab00fbb08ffd

## fluoresceina_colirio
- DailyMed/NLM EUA - Fluorescein Sodium Ophthalmic Strips 1 mg, updated 01-06-2025; monocomponent ophthalmic evidence, NOT drops. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=292abb69-84ad-4f61-e063-6394a90a1447

## lidocaina_gel
- DailyMed/NLM EUA - GLYDO lidocaine hydrochloride jelly 2%, updated 04-02-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=65760723-75cd-472c-96e1-7d05f95b4686

## nitrato_de_prata
- DailyMed/NLM EUA - Grafco Silver Nitrate Applicators 75%/25%; Unapproved Drug Other. https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=e5ebf7aa-fbe5-45b1-e053-2a95a90a5cbf

## proximetacaina_colirio
- DailyMed/NLM EUA - ALCAINE proparacaine hydrochloride ophthalmic solution 0.5%, updated 10-06-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0c0fa0bf-977d-4539-b8dc-54c187c5b094

## sulfadiazina_de_prata
- DailyMed/NLM EUA - Silver Sulfadiazine Cream 1%, updated 13-07-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b4d6694f-2b0a-4d64-9e05-2fef6d8e60d9

## tropicamida_colirio
- DailyMed/NLM EUA - Tropicamide Ophthalmic Solution 1%, updated 10-04-2026. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=378b5fe2-4b5d-4c87-a7d6-fd0caa6402af

