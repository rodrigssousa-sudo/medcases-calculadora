# MEDCASES GOLD33 - LOTE 091 - REFERENCIAS

Parecer: Dra Eugenia Marques | 20-09-2026 | APROVADO INTEGRALMENTE | Arquivo revisado: 091

## proximetacaina_colirio
- 1. DailyMed — ALCAINE proparacaine hydrochloride ophthalmic solution 0.5%, updated 2026-06-10. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0c0fa0bf-977d-4539-b8dc-54c187c5b094

## sulfadiazina_de_prata
- 1. DailyMed — Silver sulfadiazine cream USP 1%, updated 2026-07-13. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b4d6694f-2b0a-4d64-9e05-2fef6d8e60d9

## tropicamida_colirio
- 1. DailyMed — Tropicamide ophthalmic solution USP 1%, updated 2026-04-10. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=378b5fe2-4b5d-4c87-a7d6-fd0caa6402af

## azitromicina_iv
- 1. DailyMed — Azithromycin for Injection 500 mg/vial, revised 2026-08. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=55051e03-b6dc-4bc6-87c1-e4fb84b61fa3

## cefalotina
- 1. ANMAT — Disposición 9501/2021, CEFALOTINA PHARMAVIAL, prospecto autorizado. https://boletin.anmat.gob.ar/diciembre_2021/Dispo_9501-21.pdf

## ceftriaxona_im
- 1. DailyMed — Ceftriaxone for Injection USP, IM/IV label. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3b36beb7-db94-4b07-8c81-bd2b601a6601

## ceftriaxona_iv
- 1. DailyMed — Ceftriaxone for Injection USP, IM/IV label. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=3b36beb7-db94-4b07-8c81-bd2b601a6601

## ciprofloxacino_iv
- 1. DailyMed — Ciprofloxacin Injection USP, IV prescribing information. https://dailymed.nlm.nih.gov/dailymed/getFile.cfm?setid=19df63de-9f44-40ce-9a4f-0c96345b8a23

## clindamicina_iv
- 1. DailyMed — CLEOCIN PHOSPHATE clindamycin phosphate injection, updated 2026-07-29. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=05a75685-0af5-407c-ac57-e380c882b49d

## fluconazol_iv
- 1. DailyMed — Fluconazole in Sodium Chloride Injection 2 mg/mL, updated 2024-12-05. https://www.dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?audience=professional&setid=22ebc3fb-ee81-44bd-a6e3-5e759ee724a8
