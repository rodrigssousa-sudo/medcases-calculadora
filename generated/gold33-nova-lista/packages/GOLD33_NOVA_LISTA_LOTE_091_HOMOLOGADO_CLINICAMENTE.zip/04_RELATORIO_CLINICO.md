# RELATORIO CLINICO - LOTE 091

- Medico revisor: Dra Eugenia Marques
- Data: 20-09-2026
- Resultado: APROVADO INTEGRALMENTE
- Excecoes: nenhuma
- Conteudo clinico alterado apos parecer: NAO
- Bloqueios granulares: preservados
- Integracao tecnica: NAO INICIADA
- Publicacao: BLOQUEADA

## proximetacaina_colirio
Bloqueios: 2
- CALCULO_PEDIATRICO_BLOQUEADO_SEM_ALGORITMO_ESPECIFICO
- AUTOMEDICACAO_BLOQUEADA
Pendencias: 1
- Apresentação AR/BR não confirmada individualmente.

## sulfadiazina_de_prata
Bloqueios: 2
- PEDIATRIA_AUTOMATIZADA_BLOQUEADA
- USO_NEONATAL_BLOQUEADO
Pendencias: 1
- Disponibilidade AR/BR não confirmada.

## tropicamida_colirio
Bloqueios: 2
- CALCULO_PEDIATRICO_BLOQUEADO
- VIA_INJETAVEL_BLOQUEADA
Pendencias: 1
- Disponibilidade AR/BR não confirmada.

## azitromicina_iv
Bloqueios: 3
- PEDIATRIA_IV_BLOQUEADA
- BOLUS_IV_BLOQUEADO
- VIA_IM_BLOQUEADA
Pendencias: 1
- Apresentação AR/BR não confirmada.

## cefalotina
Bloqueios: 1
- PREPARO_IV_AUTOMATICO_BLOQUEADO_SEM_PRODUTO_ESPECIFICO
Pendencias: 1
- Prospecto clínico é de 2021; confirmar versão regulatória argentina vigente antes de publicação.

## ceftriaxona_im
Bloqueios: 2
- VIA_IV_BLOQUEADA_NESTA_FICHA
- NEONATOS_COM_CALCIO_IV_BLOQUEADOS
Pendencias: 1
- Bula DailyMed consultada tem atualização histórica; doses de gonorreia exigem guideline atual separado.

## ceftriaxona_iv
Bloqueios: 3
- VIA_IM_BLOQUEADA_NESTA_FICHA
- LIDOCAINA_IV_BLOQUEADA
- NEONATOS_COM_CALCIO_IV_BLOQUEADOS
Pendencias: 1
- Bula consultada é oficial, porém com histórico antigo; manter revisão regulatória local antes de publicação.

## ciprofloxacino_iv
Bloqueios: 2
- BOLUS_IV_BLOQUEADO
- PEDIATRIA_FORA_DAS_INDICACOES_DOCUMENTADAS_BLOQUEADA
Pendencias: 1
- Confirmar apresentação/rotulagem local AR/BR.

## clindamicina_iv
Bloqueios: 2
- IV_PUSH_BLOQUEADO
- PEDIATRIA_AUTOMATICA_BLOQUEADA_ATE_VALIDAR_FORMULACAO
Pendencias: 1
- Apresentação AR/BR não confirmada.

## fluconazol_iv
Bloqueios: 1
- INTERACOES_CYP_QT_EXIGEM_RECONCILIACAO_NO_MOTOR
Pendencias: 1
- Apresentação AR/BR não confirmada.
