# MEDCASES GOLD33 - Contrato de handoff Codex

## Pacote
- Tipo: complementação residual Gold33 homologada clinicamente
- IDs: 11
- Campos residuais aprovados: 75
- Valores localizados: 150 (PT/ES)
- Médica revisora: Dra Eugenia Marques
- Data: 21-09-2026
- Resultado: APROVADO INTEGRALMENTE

## Regra de aplicação
Este pacote é um **PATCH residual**, não um substituto integral dos objetos Gold33. O Codex deve aplicar somente `PATCH_CAMPOS_33` nos campos correspondentes que estejam vazios no baseline alvo. Se um campo alvo estiver não vazio ou tiver divergência de identidade/formulação/jurisdição, **não sobrescrever automaticamente**: registrar conflito e interromper apenas aquele campo/ID.

## Estados
- `PESQUISA = CONCLUIDA`
- `REVISAO_CLINICA = HOMOLOGADA`
- `HOMOLOGACAO_DADOS = SIM`
- `AUTORIZACAO_CALCULO = NAO_ALTERADA`
- `INTEGRACAO_TECNICA = LIBERADA_PARA_HANDOFF_CODEX`
- `EXECUCAO_NO_REPOSITORIO = NAO_AUTORIZADA`
- `PUBLICACAO = NAO_AUTORIZADA`

## Restrições obrigatórias
1. `aas_antiagregante.pediatricDose`: `AUTOMATABLE=NO`; não criar cálculo pediátrico universal.
2. `acetato_de_calcio.pharmacokinetics`: preservar a limitação documental; não inventar PK quantitativa.
3. `haloperidol.guidelineRecommendations`: guideline independente não modifica o escopo regulatório da solução oral argentina.
4. `infusionProtocol = NAO_APLICAVEL_COMPROVADO` vale somente para a formulação documentada; não extrapolar para outra apresentação/via.
5. Nenhum cálculo, dose engine, publicação, commit, push, merge ou deploy é autorizado por este pacote.

## Regras de integridade
- Preservar IDs exatamente: aceclofenaco, aas_antiagregante, abciximabe, acenocumarol, acetazolamida, acetilcisteina, abacavir, acetato_de_calcio, haloperidol, abatacepte, acamprosato.
- Preservar PT/ES sem alteração semântica.
- Manter `references`/`ref` já existentes fora do patch e não criar referências novas durante merge.
- Não alterar registros fora destes 11 IDs.
- Depois do merge técnico, executar validação estrutural 33/33, JSON parse, paridade PT/ES, diff exato e testes de fronteira Free/Premium do repositório.

## Evidência da aprovação
- Candidato aprovado: `MEDCASES_GOLD33_FINAL_RESIDUAL_COMPLETION_CANDIDATE_20260921.json`
- SHA-256 candidato: `b9522a062d9d4e9265db93b33b8e47e4b1fad67448dafc95c9a31ee4c466bbdb`
- PDF revisado: `MEDCASES_GOLD33_FINAL_RESIDUAL_COMPLETION_REVIEW_20260921.pdf`
- SHA-256 PDF revisado: `e192815fc1edfb99c45188585ce146bf2088b14899832e620322995d8bb062ad`

## Limite de autoridade
Este handoff certifica que o conteúdo residual foi **aprovado clinicamente** e está **pronto para o Codex avaliar/aplicar tecnicamente quando houver autorização específica para modificar o repositório**. Não é autorização de integração automática nem de publicação.
