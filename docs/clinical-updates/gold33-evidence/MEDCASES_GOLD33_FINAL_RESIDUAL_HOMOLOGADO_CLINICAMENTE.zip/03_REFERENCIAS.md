# MEDCASES Gold33 - Referências homologadas da complementação residual

- Parecer médico: **APROVADO INTEGRALMENTE**
- Médica revisora: **Dra Eugenia Marques**
- Data: **21-09-2026**
- Escopo: 11 IDs / 75 campos residuais / PT+ES.
- As referências abaixo são as mesmas usadas no candidato aprovado; nenhuma fonte foi acrescentada ou substituída após o parecer.


Data de consulta: 2026-09-21

Somente fontes efetivamente utilizadas para os 75 campos propostos.

1. **ACE_EMC - Preservex 100 mg film-coated tablets - SmPC**
   - Emissor: electronic Medicines Compendium (UK)
   - Jurisdição/escopo: UK
   - URL: https://www.medicines.org.uk/emc/product/6578/smpc

2. **NICE_OA - Osteoarthritis in over 16s: diagnosis and management (NG226)**
   - Emissor: NICE
   - Jurisdição/escopo: UK
   - URL: https://www.nice.org.uk/guidance/ng226/chapter/Recommendations

3. **NICE_RA - Rheumatoid arthritis in adults: management (NG100)**
   - Emissor: NICE
   - Jurisdição/escopo: UK
   - URL: https://www.nice.org.uk/guidance/ng100/chapter/Recommendations

4. **AAS_EMC - Aspirin 75 mg Gastro-Resistant Tablets - SmPC**
   - Emissor: electronic Medicines Compendium (UK)
   - Jurisdição/escopo: UK
   - URL: https://www.medicines.org.uk/emc/product/2614/smpc

5. **ACR_KD_2021 - 2021 ACR/Vasculitis Foundation Guideline for Management of Kawasaki Disease**
   - Emissor: American College of Rheumatology / Vasculitis Foundation
   - Jurisdição/escopo: US guideline
   - URL: https://vasculitisfoundation.org/wp-content/uploads/2024/01/Guideline-Management-Kawasaki-Disease.pdf

6. **AHA_KD_2024 - Update on Diagnosis and Management of Kawasaki Disease: A Scientific Statement**
   - Emissor: American Heart Association
   - Jurisdição/escopo: International/US guideline
   - URL: https://www.ahajournals.org/doi/10.1161/CIR.0000000000001295

7. **FDA_ABCIXIMAB - ReoPro (abciximab) FDA Prescribing Information**
   - Emissor: FDA
   - Jurisdição/escopo: US
   - URL: https://www.accessdata.fda.gov/drugsatfda_docs/label/2019/103575s5138lbl.pdf

8. **ACS_2025 - 2025 ACC/AHA/ACEP/NAEMSP/SCAI Guideline for Acute Coronary Syndromes**
   - Emissor: ACC/AHA/ACEP/NAEMSP/SCAI
   - Jurisdição/escopo: US guideline
   - URL: https://www.ahajournals.org/doi/10.1161/CIR.0000000000001309

9. **SINTHROME_EMC - Sinthrome 1 mg Tablets - SmPC**
   - Emissor: electronic Medicines Compendium (UK)
   - Jurisdição/escopo: UK
   - URL: https://www.medicines.org.uk/emc/product/2058/smpc

10. **ESC_AF_2024 - 2024 ESC Guidelines for the management of atrial fibrillation**
   - Emissor: European Society of Cardiology
   - Jurisdição/escopo: Europe guideline
   - URL: https://academic.oup.com/eurheartj/article/45/36/3314/7738779

11. **DIAMOX_EMC - Diamox 250 mg Tablets - SmPC**
   - Emissor: electronic Medicines Compendium (UK)
   - Jurisdição/escopo: UK
   - URL: https://www.medicines.org.uk/emc/product/15349/smpc

12. **ACETAZOLAMIDE_EMC - Acetazolamide 250 mg Tablet - SmPC**
   - Emissor: electronic Medicines Compendium (UK)
   - Jurisdição/escopo: UK
   - URL: https://www.medicines.org.uk/emc/product/100949/smpc

13. **IIH_2025 - Diagnosis, treatment and monitoring of idiopathic intracranial hypertension: Austrian IIH network consensus**
   - Emissor: Austrian Network for Idiopathic Intracranial Hypertension
   - Jurisdição/escopo: Austria/consensus
   - URL: https://journals.sagepub.com/doi/10.1177/03331024251391374

14. **ACETADOTE - ACETADOTE (acetylcysteine) injection - Prescribing Information**
   - Emissor: DailyMed/FDA SPL
   - Jurisdição/escopo: US
   - URL: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=472f158a-5ab9-4308-8e49-1116e6ea3d39

15. **ACMT_NAC_2026 - Duration of Intravenous Acetylcysteine Therapy following Acetaminophen Overdose (2026 update)**
   - Emissor: American College of Medical Toxicology
   - Jurisdição/escopo: US practice statement
   - URL: https://www.acmt.net/news/acmt-practice-statement-duration-of-intravenous-acetylcysteine-therapy-following-acetaminophen-overdose-2026-update/

16. **ZIAGEN - ZIAGEN (abacavir sulfate) oral solution - Prescribing Information**
   - Emissor: DailyMed/FDA SPL
   - Jurisdição/escopo: US
   - URL: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=ca73b519-015a-436d-aa3c-af53492825a1

17. **NIH_HIV - NIH Adult and Adolescent ARV Guidelines - Initial ART based on clinical scenarios**
   - Emissor: NIH ClinicalInfo
   - Jurisdição/escopo: US guideline
   - URL: https://clinicalinfo.hiv.gov/en/guidelines/hiv-clinical-guidelines-adult-and-adolescent-arv/what-start-initial-antiretroviral-specific-clinical-scenarios

18. **CALCIUM_ACETATE - Calcium Acetate Capsules, USP 667 mg - Prescribing Information**
   - Emissor: DailyMed/FDA SPL
   - Jurisdição/escopo: US
   - URL: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=2072d9f4-abb1-4699-bde5-6041dd79cad5

19. **KDIGO_CKD_MBD - KDIGO 2017 Clinical Practice Guideline Update for CKD-MBD**
   - Emissor: KDIGO
   - Jurisdição/escopo: International guideline
   - URL: https://kdigo.org/wp-content/uploads/2026/04/KDIGO-2017-CKD-MBD-Guideline.pdf

20. **WHO_HALOPERIDOL - Antipsychotic medicines for psychotic disorders - 2023 updated recommendation**
   - Emissor: World Health Organization mhGAP
   - Jurisdição/escopo: International guideline
   - URL: https://www.who.int/teams/mental-health-and-substance-use/treatment-care/mental-health-gap-action-programme/evidence-centre/psychosis-and-bipolar-disorders/antipsychotic-medicines-for-psychotic-disorders

21. **ORENCIA - ORENCIA (abatacept) - Prescribing Information**
   - Emissor: DailyMed/FDA SPL
   - Jurisdição/escopo: US
   - URL: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=0836c6ac-ee37-5640-2fed-a3185a0b16eb

22. **EULAR_RA_2025 - EULAR recommendations for management of rheumatoid arthritis: 2025 update**
   - Emissor: EULAR
   - Jurisdição/escopo: Europe guideline
   - URL: https://www.eular.org/recommendations-management

23. **EULAR_RA_2022 - EULAR recommendations for management of rheumatoid arthritis: 2022 update**
   - Emissor: EULAR / Annals of the Rheumatic Diseases
   - Jurisdição/escopo: Europe guideline
   - URL: https://ard.bmj.com/content/82/1/3

24. **ACAMPROSATE - Acamprosate calcium delayed-release tablets - Prescribing Information**
   - Emissor: DailyMed/FDA SPL
   - Jurisdição/escopo: US
   - URL: https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=4473326f-79f1-61b2-e063-6294a90a17a3

25. **NICE_ALCOHOL - Alcohol-use disorders: diagnosis, assessment and management of harmful drinking and alcohol dependence (CG115)**
   - Emissor: NICE
   - Jurisdição/escopo: UK guideline
   - URL: https://www.nice.org.uk/guidance/cg115/chapter/Recommendations
