# MEDCASES GOLD33 - Complementação residual

Data: 2026-09-21

- IDs processados: 11 (pacote residual; não é novo lote Gold33 de 10).
- Campos residuais identificados no PDF: 75.
- Valores PT/ES propostos: 150.
- Campos vazios após este patch: 0/75.
- Publicação: BLOQUEADA.
- Integração: NÃO AUTORIZADA.
- Revisão médica: PENDENTE.

## Bloqueios/limitações preservados

- `aas_antiagregante.pediatricDose`: preenchido apenas com escopo por indicação (Kawasaki) e `AUTOMATABLE=NO`; não existe dose pediátrica antiagregante universal para o ID.
- `acetato_de_calcio.pharmacokinetics`: a fonte regulatória atual não oferece PK sistêmica quantitativa completa; o campo foi preenchido com essa limitação documentada, sem inventar números.
- Campos `infusionProtocol` de produtos exclusivamente orais foram preenchidos como `NAO_APLICAVEL_COMPROVADO` somente para a formulação documentada.
- `haloperidol.guidelineRecommendations` usa OMS/mhGAP como guideline independente e não altera o escopo regulatório da solução oral argentina previamente documentada.
- Nenhum cálculo foi ativado por este patch.
