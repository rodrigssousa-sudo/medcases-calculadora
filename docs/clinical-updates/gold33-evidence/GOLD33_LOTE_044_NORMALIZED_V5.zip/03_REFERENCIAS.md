# Referências - Lote 044

## itoprida
- Fonte oficial/primária - https://pubmed.ncbi.nlm.nih.gov/39989849/
- Fonte oficial/primária - https://pubmed.ncbi.nlm.nih.gov/35357058/

## itraconazol
- Fonte oficial/primária - https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=23126370-8d6a-4027-bd8f-860e2776ba3a

## ivabradina
- Fonte oficial/primária - https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=92018a65-38f6-45f7-91d4-a34921b81d0d
- Fonte oficial/primária - https://professional.heart.org/en/science-news/2022-guideline-for-the-management-of-heart-failure

## ketamina
- Fonte oficial/primária - https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=b96a0a23-3ca0-4a92-bd8b-1e9921931772
- Fonte oficial/primária - https://www.rch.org.au/clinicalguide/guideline_index/Ketamine_use_for_procedural_sedation/

## labetalol
- Fonte oficial/primária - https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=99a715a0-4579-410c-b102-7ef6fab8db55
- Fonte oficial/primária - https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=abfc6b75-1ed5-41f1-0484-4597488237bc

## lacosamida
- Fonte oficial/primária - https://dailymed.nlm.nih.gov/dailymed/lookup.cfm?setid=6140b3f1-ff60-427c-91d7-15af99fd78f1&version=7

## lactulose
- Fonte oficial/primária - https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=a8af7389-3699-4873-b05a-509af7e8eaab

## lamivudina
- Fonte oficial/primária - https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=89226149-47fa-4f7d-bb1f-1aa7034486b8

## lamotrigina
- Fonte oficial/primária - https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=1d7c2d52-a78e-4508-8853-ba306cdeeaba

## lansoprazol
- Fonte oficial/primária - https://dailymed.nlm.nih.gov/dailymed/drugInfo.cfm?setid=7daa1721-f92b-4096-b19e-4d27fc8acb51